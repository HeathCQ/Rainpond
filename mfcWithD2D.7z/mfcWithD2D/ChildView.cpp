﻿
// ChildView.cpp : CChildView 类的实现
//

#include "stdafx.h"
#include "mfcWithD2D.h"
#include "ChildView.h"


static UINT32 ColorRGB(COLORREF clr)
{
    UINT32 rgb;

    BYTE r = clr & 0xFF;
    BYTE g = (clr & 0xFF00) >> 8;
    BYTE b = (clr & 0xFF0000) >> 16;

    rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return rgb;
}

static UINT32 ColorRGB(BYTE r, BYTE g, BYTE b)
{
    return (UINT32)(((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));
}

static D2D1::ColorF ColorRGBA(COLORREF clr, FLOAT alpha = 10.0F)
{
    UINT32 rgb;

    BYTE r = clr & 0xFF;
    BYTE g = (clr & 0xFF00) >> 8;
    BYTE b = (clr & 0xFF0000) >> 16;

    rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return D2D1::ColorF::ColorF(clr, alpha);
}

static D2D1::ColorF ColorRGBA(BYTE r, BYTE g, BYTE b, FLOAT alpha = 10.0F)
{
    UINT32 rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return D2D1::ColorF::ColorF(rgb, alpha);
}

#define ReleaseCOM(com) { if (com) { com->Release(); com = nullptr;}}

static ID2D1Factory *          g_factory;
static ID2D1DCRenderTarget   * g_dc_render_target;
static ID2D1SolidColorBrush  * g_brush;
static ID2D1StrokeStyle      * g_stroke_style;

static IWICImagingFactory * g_image_factory = NULL;


static ID2D1Bitmap * g_bitmap = NULL;
static CBitmap *     g_gdiBitmap = NULL;

static int InitDirect2D();

// CChildView

BEGIN_MESSAGE_MAP(CChildView, CWnd)
    ON_WM_CREATE()
    ON_WM_DESTROY()
    ON_WM_PAINT()
    ON_WM_ERASEBKGND()
    ON_WM_SIZE()
    ON_WM_MOUSEWHEEL()
    ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
    ON_WM_ACTIVATE()
    ON_WM_SETFOCUS()
    ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

CChildView::CChildView()
{
    m_lpszImagePath = NULL;

    m_Scale = 1.0f;
}

CChildView::~CChildView()
{
}

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs)
{
    if (!CWnd::PreCreateWindow(cs))
        return FALSE;

    cs.style &= ~WS_BORDER;

    cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
    
	cs.lpszClass = AfxRegisterWndClass(
                        CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		                0, 
                        reinterpret_cast<HBRUSH>(COLOR_WINDOW+1),
                        0);
    return TRUE;
}

int  CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

    if (!InitDirect2D())
        return -1;

    g_dc_render_target->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Red), &g_brush);

    g_factory->CreateStrokeStyle(
        D2D1::StrokeStyleProperties(
            D2D1_CAP_STYLE_FLAT,
            D2D1_CAP_STYLE_FLAT,
            D2D1_CAP_STYLE_FLAT,
            D2D1_LINE_JOIN_MITER,
            10.0f,
            D2D1_DASH_STYLE_CUSTOM,
            10.0f),
        NULL,
        0,
        &g_stroke_style);

    return 0;
}

void CChildView::OnDestroy()
{
    CWnd::OnDestroy();

    ReleaseCOM(g_factory);
    ReleaseCOM(g_dc_render_target);
    ReleaseCOM(g_brush);
    ReleaseCOM(g_stroke_style);
    ReleaseCOM(g_image_factory);
    ReleaseCOM(g_bitmap);

    if (g_gdiBitmap)
    {
        HGDIOBJ hGdiObj = g_gdiBitmap->Detach();
        ::DeleteObject(hGdiObj);
        delete g_gdiBitmap;
        g_gdiBitmap = NULL;
    }
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);

    CRect clientRect;
    GetClientRect(&clientRect);

//     CRect gdiRect = clientRect;
//     gdiRect.right -= (gdiRect.Width() / 2);

    CRect d2dRect = clientRect;
    //d2dRect.left += (d2dRect.Width() / 2);

    // gdi

//     CDC mdc;
//     CBitmap mbmp;
//     mdc.CreateCompatibleDC(&dc);
//     mbmp.CreateCompatibleBitmap(&dc, gdiRect.Width(), gdiRect.Height());
//     mdc.SelectObject(&mbmp);
//     dc.BitBlt(0, 0, gdiRect.Width(), gdiRect.Height(), &mdc, 0, 0, SRCCOPY);
// 
//     DrawBitmap(&dc, &mdc, g_gdiBitmap);
//     //DisplayBitmap(&dc, &mdc, m_lpszImagePath);
// 
//     mbmp.DeleteObject();
//     mdc.DeleteDC();

    // d2d

    if (!g_dc_render_target)
        return;

    g_dc_render_target->BindDC(dc.m_hDC, &d2dRect);

    g_dc_render_target->BeginDraw();
    g_dc_render_target->SetTransform(D2D1::Matrix3x2F::Identity());
    //g_dc_render_target->Clear(D2D1::ColorF(0.63f, 0.84f, 0.25f));
    g_dc_render_target->Clear(ColorRGBA(51, 103, 214));

//     g_dc_render_target->DrawLine(D2D1::Point2F(0.0f, 0.0f), 
//                                  D2D1::Point2F(100.0f, 100.0f), 
//                                  g_brush,
//                                  1.0f,
//                                  g_stroke_style);

    //g_dc_render_target->DrawRectangle(D2D1::RectF(100, 100, 400, 400), g_brush, 1.0f, g_stroke_style);

    //g_dc_render_target->FillRectangle(D2D1::RectF(100, 100, 400, 400), g_brush);

    D2D1_SIZE_F render_size = g_dc_render_target->GetSize();

    // Draw Image
    if (g_bitmap)
    {
        D2D1_SIZE_F imageSize = g_bitmap->GetSize();
        float cx = imageSize.width * m_Scale;
        float cy = imageSize.height * m_Scale;
        FLOAT x = int(render_size.width - cx) / 2;
        FLOAT y = int(render_size.height - cy) / 2;
        g_dc_render_target->DrawBitmap(g_bitmap, D2D1::RectF(x, y, x + cx, y + cy));
    }
    
    g_dc_render_target->EndDraw();

    dc.TextOut(10, 10, m_Text);
}

BOOL CChildView::OnEraseBkgnd(CDC* pDC)
{
    return TRUE;
}

void CChildView::OnSize(UINT nType, int cx, int cy)
{
    CWnd::OnSize(nType, cx, cy);

    Redraw();
}

BOOL CChildView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
    if (zDelta > 0)
    {
        m_Scale *= 0.9f;
    }
    else
    {
        m_Scale /= 0.9f;
    }

    Redraw();

    return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}

void CChildView::OnFileOpen()
{
    BOOL bOpen = TRUE;
    CString filter = L"图片(*.*)|*.*||";

    CFileDialog openFileDlg(bOpen, NULL, NULL,
                            OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
                            filter, NULL);
    INT_PTR result = openFileDlg.DoModal();

    if (result == IDOK)
    {
        CString pathName = openFileDlg.GetPathName();
        CString fileName = openFileDlg.GetFileName();
        CString titleName = openFileDlg.GetFileTitle();
        CString extName = openFileDlg.GetFileExt();

//         CString msg;
//         msg.Append(_T("图片途径：   "));
//         msg.Append(pathName);
//         msg.Append(_T("\r\n"));
//         msg.Append(_T("图片文件名： "));
//         msg.Append(fileName);
//         msg.Append(_T("\r\n"));
//         msg.Append(_T("图片名称：   "));
//         msg.Append(titleName);
//         msg.Append(_T("\r\n"));
//         msg.Append(_T("图片扩展名： "));
//         msg.Append(extName);
//         MessageBox(msg);//通过显示，注意几者区别

        DisplayImage(pathName);

        Redraw();
    }
}

void CChildView::DisplayBitmap(CDC *pDestDC, CDC *pSourDC, UINT nResourceID)
{
    CBitmap bitmap;
    if (!bitmap.LoadBitmap(nResourceID))
    {
        return;
    }
    DrawBitmap(pDestDC, pSourDC, &bitmap);

    bitmap.DeleteObject();
}

void CChildView::DisplayBitmap(CDC *pDestDC, CDC *pSourDC, LPCTSTR lpszPath)
{
    CBitmap bitmap;

    HBITMAP hbmp = qxLoadBitmap(lpszPath);

    if (hbmp)
    {
        bitmap.Attach(hbmp);

        DrawBitmap(pDestDC, pSourDC, &bitmap);

        bitmap.Detach();
        ::DeleteObject(hbmp);
    }
}

void CChildView::DrawBitmap(CDC *pDestDC, CDC *pSourDC, CBitmap *pBitmap)
{
    if (!pBitmap)
        return;

    BITMAP bm;
    pBitmap->GetBitmap(&bm);
    CBitmap *pSavedBitmap = pSourDC->SelectObject(pBitmap);

    CRect clientRect;
    GetWindowRect(&clientRect);

    CRect gdiRect = clientRect;
    gdiRect.right -= (gdiRect.Width() / 2);

    int x = (gdiRect.Width() - bm.bmWidth) / 2;
    int y = (gdiRect.Height() - bm.bmHeight) / 2;

    pDestDC->StretchBlt(x, y, bm.bmWidth, bm.bmHeight,
                        pSourDC,
                        0, 0, bm.bmWidth, bm.bmHeight,
                        SRCCOPY);

    pSourDC->SelectObject(pSavedBitmap);
}

void CChildView::DisplayImage(LPCTSTR lpszImagePath)
{
    if (lpszImagePath == NULL || lpszImagePath[0] == 0)
        return;

    m_lpszImagePath = lpszImagePath;

    // d2d load bitmap resource

    IWICBitmapDecoder *bitmapdecoder = NULL;
    if (FAILED(g_image_factory->CreateDecoderFromFilename(m_lpszImagePath,
                                    NULL, GENERIC_READ, WICDecodeMetadataCacheOnDemand, 
                                    &bitmapdecoder)))
    {
        return;
    }

    if (g_bitmap)
    {
        g_bitmap->Release();
        g_bitmap = NULL;
    }

    IWICBitmapFrameDecode  *pframe = NULL;
    bitmapdecoder->GetFrame(0, &pframe);

    IWICFormatConverter * fmtcovter = NULL;
    g_image_factory->CreateFormatConverter(&fmtcovter);
    fmtcovter->Initialize(pframe, 
                          GUID_WICPixelFormat32bppPBGRA,
                          WICBitmapDitherTypeNone,
                          NULL,
                          0.0f, 
                          WICBitmapPaletteTypeCustom);
    g_dc_render_target->CreateBitmapFromWicBitmap(fmtcovter, NULL, &g_bitmap);

    fmtcovter->Release();
    pframe->Release();
    bitmapdecoder->Release();

    // gdi load bitmap resource

    if (g_gdiBitmap)
    {
        HGDIOBJ hGdiObj = g_gdiBitmap->Detach();
        ::DeleteObject(hGdiObj);
        delete g_gdiBitmap;
        g_gdiBitmap = NULL;
    }

    HBITMAP hbmp = qxLoadBitmap(m_lpszImagePath);

    if (hbmp)
    {
        g_gdiBitmap = new CBitmap;
        g_gdiBitmap->Attach(hbmp);
    }
}

HBITMAP CChildView::qxLoadBitmap(LPCTSTR lpszPathName)
{
    if (lpszPathName == NULL || lpszPathName[0] == 0)
        return NULL;

    return (HBITMAP)::LoadImage(AfxGetApp()->m_hInstance,
                                lpszPathName,
                                IMAGE_BITMAP,
                                0, 0,
                                LR_DEFAULTCOLOR | LR_LOADFROMFILE);
}

HICON CChildView::qxLoadIcon(LPCTSTR lpszPathName)
{
    if (lpszPathName == NULL || lpszPathName[0] == 0)
        return NULL;

    return (HICON)::LoadImage(AfxGetApp()->m_hInstance,
        lpszPathName,
                                IMAGE_ICON,
                                0, 0,
                                LR_DEFAULTCOLOR | LR_LOADFROMFILE);
}

HCURSOR CChildView::qxLoadCursor(LPCTSTR lpszPathName)
{
    if (lpszPathName == NULL || lpszPathName[0] == 0)
        return NULL;

    return (HCURSOR)::LoadImage(AfxGetApp()->m_hInstance,
        lpszPathName,
        IMAGE_CURSOR,
        0, 0,
        LR_DEFAULTCOLOR | LR_LOADFROMFILE);
}


static int InitDirect2D()
{
    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

    D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &g_factory);

    D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
        D2D1_RENDER_TARGET_TYPE_DEFAULT,
        D2D1::PixelFormat(
            DXGI_FORMAT_B8G8R8A8_UNORM,
            D2D1_ALPHA_MODE_IGNORE),
        0,
        0,
        D2D1_RENDER_TARGET_USAGE_NONE,
        D2D1_FEATURE_LEVEL_DEFAULT
    );

    g_factory->CreateDCRenderTarget(&props, &g_dc_render_target);


    // Initialize Image Factory
    CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER,
                     __uuidof(g_image_factory), (LPVOID*)&g_image_factory);

    return 1;
}

void CChildView::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
    CWnd::OnActivate(nState, pWndOther, bMinimized);

    if (nState == WA_ACTIVE)
    {
        m_Text = _T("Activated");
    }
    else if (nState == WA_CLICKACTIVE)
    {
        m_Text = _T("Click Activated");
    }
    else if (nState == WA_INACTIVE)
    {
        m_Text = _T("InActivated");
    }

    Redraw();
}

void CChildView::OnSetFocus(CWnd* pOldWnd)
{
    CWnd::OnSetFocus(pOldWnd);

    m_Text = _T("Focus On");

    Redraw();
}

void CChildView::OnKillFocus(CWnd* pNewWnd)
{
    CWnd::OnKillFocus(pNewWnd);

    m_Text = _T("Lose Focus");

    Redraw();
}

void CChildView::Redraw(LPRECT lpRect, BOOL bErase)
{
    InvalidateRect(lpRect, bErase);
    UpdateWindow();
}
