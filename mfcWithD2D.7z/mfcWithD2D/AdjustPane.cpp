// AdjustPane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mfcWithD2D.h"
#include "AdjustPane.h"
#include "ThreeDView.h"


// CAdjustPane


IMPLEMENT_DYNCREATE(CAdjustPane, CFormView)


CAdjustPane::CAdjustPane()
	: CFormView(IDD_ADJUSTPANE)
{

}

CAdjustPane::~CAdjustPane()
{
}


void CAdjustPane::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CAdjustPane::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: �ڴ�����ר�ô����/����û���

    cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

    return CFormView::PreCreateWindow(cs);
}

void CAdjustPane::OnInitialUpdate()
{
    CFormView::OnInitialUpdate();

    // TODO: �ڴ�����ר�ô����/����û���

    InitPerspectiveProjectionPane();

    InitParallelProjectionPane();
}

BEGIN_MESSAGE_MAP(CAdjustPane, CFormView)
    ON_WM_SIZE()
    ON_WM_HSCROLL()
    ON_COMMAND(IDC_BTN_PERSPECTIVE_PROJECTION, OnBtnPerspectiveProjection)
    ON_COMMAND(IDC_BTN_PARALLEL_PROJECTION, OnBtnParallelProjection)
    ON_COMMAND(IDC_BTN_DEFAULT_PERSPECTIVE_PARAMETER, OnBtnDefaultPerspectiveParameter)
    ON_COMMAND(IDC_BTN_DEFAULT, OnBtnDefault)
END_MESSAGE_MAP()


// CAdjustPane ��Ϣ��������


void CAdjustPane::OnSize(UINT nType, int cx, int cy)
{
    CFormView::OnSize(nType, cx, cy);

    CWnd *separatorWnd = GetDlgItem(IDC_STA_SEPARATOR);

    if (separatorWnd)
    {
        CRect clientRect, separatorRect;

        GetClientRect(&clientRect);

        separatorWnd->GetWindowRect(&separatorRect);

        ScreenToClient(&separatorRect);

        separatorRect.left = clientRect.left;
        separatorRect.right = clientRect.right;

        separatorWnd->MoveWindow(&separatorRect);
    }
}

void CAdjustPane::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);
    CSliderCtrl *slider = NULL;
    CStatic *staticCtrl = NULL;
    int iPos;
    CString text;

    switch (pScrollBar->GetDlgCtrlID())
    {
    case IDC_SLIDER_CX:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CX);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_CX);

        ShowSliderPosition(slider, staticCtrl);

        threeDView->SetCameraCx((float)slider->GetPos());
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_CY:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CY);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_CY);

        ShowSliderPosition(slider, staticCtrl);

        threeDView->SetCameraCy((float)slider->GetPos());
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_CZ:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CZ);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_CZ);

        ShowSliderPosition(slider, staticCtrl);

        threeDView->SetCameraCz((float)slider->GetPos());
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_ROTX:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTX);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_XROTATION);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetCameraRotx((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_ROTY:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTY);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_YROTATION);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetCameraRoty((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_ROTZ:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTZ);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_ZROTATION);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetCameraRotz((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_ZAXISROTANGLE:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ZAXISROTANGLE);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_ZAXISROTANGLE);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetZAxisRotAngle((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_XAXISROTANGLE:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_XAXISROTANGLE);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_XAXISROTANGLE);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetXAxisRotAngle((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    case IDC_SLIDER_YAXISROTANGLE:
    {
        slider = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_YAXISROTANGLE);
        staticCtrl = (CStatic *)GetDlgItem(IDC_STA_SHOW_YAXISROTANGLE);

        ShowSliderPosition(slider, staticCtrl);

        iPos = slider->GetPos();
        threeDView->SetYAxisRotAngle((float)iPos * M_PI / 180.f);
        threeDView->UpdateView();
        break;
    }
    default:
        break;
    }

    CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CAdjustPane::OnBtnPerspectiveProjection()
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    threeDView->SetShowPerspective(true);
}

void CAdjustPane::OnBtnParallelProjection()
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    threeDView->SetShowPerspective(false);
}

void CAdjustPane::OnBtnDefaultPerspectiveParameter()
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    threeDView->InitCameraParameter();
    threeDView->UpdateView();

    InitPerspectiveProjectionPane();
}

void CAdjustPane::OnBtnDefault()
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    threeDView->InitParallelProjectionParameter();
    threeDView->UpdateView();

    InitParallelProjectionPane();
}

void CAdjustPane::InitPerspectiveProjectionPane()
{
    CSliderCtrl *sliderCx = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CX);
    CSliderCtrl *sliderCy = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CY);
    CSliderCtrl *sliderCz = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_CZ);
    CSliderCtrl *sliderRotx = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTX);
    CSliderCtrl *sliderRoty = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTY);
    CSliderCtrl *sliderRotz = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ROTZ);

    CStatic *staticCx = (CStatic *)GetDlgItem(IDC_STA_SHOW_CX);
    CStatic *staticCy = (CStatic *)GetDlgItem(IDC_STA_SHOW_CY);
    CStatic *staticCz = (CStatic *)GetDlgItem(IDC_STA_SHOW_CZ);
    CStatic *staticXRotation = (CStatic *)GetDlgItem(IDC_STA_SHOW_XROTATION);
    CStatic *staticYRotation = (CStatic *)GetDlgItem(IDC_STA_SHOW_YROTATION);
    CStatic *staticZRotation = (CStatic *)GetDlgItem(IDC_STA_SHOW_ZROTATION);

    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    if (sliderCx)
    {
        sliderCx->SetRange(-10, 10);
        sliderCx->SetPos(threeDView->GetCameraCx());

        if (staticCx)
        {
            ShowSliderPosition(sliderCx, staticCx);
        }
    }

    if (sliderCy)
    {
        sliderCy->SetRange(-10, 10);
        sliderCy->SetPos(threeDView->GetCameraCy());

        if (staticCy)
        {
            ShowSliderPosition(sliderCy, staticCy);
        }
    }

    if (sliderCz)
    {
        sliderCz->SetRange(-10, 10);
        sliderCz->SetPos(threeDView->GetCameraCz());

        if (staticCz)
        {
            ShowSliderPosition(sliderCz, staticCz);
        }
    }

    if (sliderRotx)
    {
        sliderRotx->SetRange(0, 360);
        sliderRotx->SetPos(threeDView->GetCameraRotx() / M_PI * 180.0f);

        if (staticXRotation)
        {
            ShowSliderPosition(sliderRotx, staticXRotation);
        }
    }

    if (sliderRoty)
    {
        sliderRoty->SetRange(0, 360);
        sliderRoty->SetPos(threeDView->GetCameraRoty() / M_PI * 180.0f);

        if (staticYRotation)
        {
            ShowSliderPosition(sliderRoty, staticYRotation);
        }
    }

    if (sliderRotz)
    {
        sliderRotz->SetRange(0, 360);
        sliderRotz->SetPos(threeDView->GetCameraRotz() / M_PI * 180.0f);

        if (staticZRotation)
        {
            ShowSliderPosition(sliderRotz, staticZRotation);
        }
    }
}

void CAdjustPane::InitParallelProjectionPane()
{
    CSliderCtrl *sliderZAxisRotAngle = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_ZAXISROTANGLE);
    CSliderCtrl *sliderXAxisRotAngle = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_XAXISROTANGLE);
    CSliderCtrl *sliderYAxisRotAngle = (CSliderCtrl *)GetDlgItem(IDC_SLIDER_YAXISROTANGLE);

    CStatic *staticZAxisRotAngle = (CStatic *)GetDlgItem(IDC_STA_SHOW_ZAXISROTANGLE);
    CStatic *staticXAxisRotAngle = (CStatic *)GetDlgItem(IDC_STA_SHOW_XAXISROTANGLE);
    CStatic *staticYAxisRotAngle = (CStatic *)GetDlgItem(IDC_STA_SHOW_YAXISROTANGLE);

    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CThreeDView *threeDView = (CThreeDView *)splitWnd->GetPane(0, 0);

    if (sliderZAxisRotAngle)
    {
        sliderZAxisRotAngle->SetRange(0, 360);

        float degree = threeDView->GetZAxisRotAngle() / M_PI * 180.0f;
        sliderZAxisRotAngle->SetPos((int)degree);

        if (staticZAxisRotAngle)
        {
            ShowSliderPosition(sliderZAxisRotAngle, staticZAxisRotAngle);
        }
    }

    if (sliderXAxisRotAngle)
    {
        sliderXAxisRotAngle->SetRange(-360, 0);

        float degree = threeDView->GetXAxisRotAngle() / M_PI * 180.0f;
        sliderXAxisRotAngle->SetPos(degree);

        if (staticXAxisRotAngle)
        {
            ShowSliderPosition(sliderXAxisRotAngle, staticXAxisRotAngle);
        }
    }

    if (sliderYAxisRotAngle)
    {
        sliderYAxisRotAngle->SetRange(0, 360);

        float degree = threeDView->GetYAxisRotAngle() / M_PI * 180.0f;
        sliderYAxisRotAngle->SetPos(degree);

        if (staticYAxisRotAngle)
        {
            ShowSliderPosition(sliderYAxisRotAngle, staticYAxisRotAngle);
        }
    }
}

void CAdjustPane::ShowSliderPosition(CSliderCtrl *sliderCtrl, CStatic *staticCtrl)
{
    CString text;

    text.Format(_T("%d"), sliderCtrl->GetPos());
    staticCtrl->SetWindowText(text);

    CRect staticRect;
    staticCtrl->GetWindowRect(&staticRect);
    ScreenToClient(&staticRect);

    int width = staticRect.Width();

    CRect sliderRect;
    sliderCtrl->GetWindowRect(&sliderRect);
    ScreenToClient(&sliderRect);

    CRect thumbRect;
    sliderCtrl->GetThumbRect(&thumbRect);

    staticRect.left = sliderRect.left + thumbRect.left + thumbRect.Width() / 2 - width / 2;
    staticRect.right = sliderRect.left + thumbRect.left + thumbRect.Width() / 2 + width / 2;

    staticCtrl->MoveWindow(&staticRect);
}




