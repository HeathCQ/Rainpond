#pragma once


// CQxDockPane

class CQxDockPane : public CPane
{
	DECLARE_DYNAMIC(CQxDockPane)

public:
	CQxDockPane();
	virtual ~CQxDockPane();
    

public:
    LPCTSTR m_lpszClassName;
    HICON   m_hIcon;

protected:
	DECLARE_MESSAGE_MAP()
public:
    
};


