#pragma once

#include <DirectXMath.h>
using namespace DirectX;


struct _3dPoint3F
{
    float x;
    float y;
    float z;

    _3dPoint3F()
    {
        x = y = z = 0.0f;
    }

    _3dPoint3F(float x, float y, float z)
    {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    _3dPoint3F(const _3dPoint3F & point3f)
    {
        *(this) = point3f;
    }
};

void Translation(_3dPoint3F &P, float tx, float ty, float tz);
void Rotation(_3dPoint3F &P, float rotx, float toty, float rotz);
void Scale(_3dPoint3F &P, float scale);

void Translation(
    float &x, float &y, float &z,
    float tx, float ty, float tz);
void Rotation(
    float &x, float &y, float &z,
    float rotx, float toty, float rotz);
void Scale(float &x, float &y, float &z, float scale);

DirectX::XMFLOAT4 VectorMultiplyMatrix(const DirectX::XMFLOAT4 &v, 
                                       const DirectX::XMMATRIX &m);


float RadianAdd(float radian, float delta, float rangeMin, float rangMax);
