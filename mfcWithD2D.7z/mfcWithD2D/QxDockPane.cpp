// QxDockPane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mfcWithD2D.h"
#include "QxDockPane.h"


// CQxDockPane


IMPLEMENT_DYNAMIC(CQxDockPane, CPane)


CQxDockPane::CQxDockPane()
{
    m_hIcon = ::LoadIcon(NULL, MAKEINTRESOURCE(IDI_LOGO));
    m_lpszClassName = AfxRegisterWndClass(CS_DBLCLKS | CS_VREDRAW | CS_HREDRAW, NULL, NULL, m_hIcon);
}

CQxDockPane::~CQxDockPane()
{

}


BEGIN_MESSAGE_MAP(CQxDockPane, CPane)
END_MESSAGE_MAP()



// CQxDockPane ��Ϣ��������
