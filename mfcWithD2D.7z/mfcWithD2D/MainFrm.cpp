﻿
// MainFrm.cpp : CMainFrame 类的实现
//

#include "stdafx.h"
#include "mfcWithD2D.h"
#include "MainFrm.h"
#include "QxBaseWnd.h"

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
    ON_WM_CREATE()
    ON_WM_SETFOCUS()
    ON_WM_SIZE()
END_MESSAGE_MAP()

CMainFrame::CMainFrame()
{
	m_hIcon = LoadIcon(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDI_LOGO));
    m_hIconSmall = LoadIcon(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDI_LOGO_SMALL));
}

CMainFrame::~CMainFrame()
{

}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);

	return TRUE;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
    CRect clientRect;
    GetWindowRect(&clientRect);

    int width = clientRect.Width();
    int hight = clientRect.Height();

    if (!m_splitWnd.CreateStatic(this, 1, 2, WS_CHILD | WS_VISIBLE))
    {
        TRACE(_T("Failed to cteate splitterWnd."));
        return FALSE;
    }

    if (!m_splitWnd.CreateView(0, 0, RUNTIME_CLASS(CThreeDView),
                        CSize(width - 200, hight), pContext))
    {
        TRACE(_T("splitterwnd failed to cteate view CThreeDView."));
        return FALSE;
    }

    if (!m_splitWnd.CreateView(0, 1, RUNTIME_CLASS(CAdjustPane),
                        CSize(220, hight), pContext))
    {
        TRACE(_T("splitterwnd failed to cteate view CAdjustPane."));
        return FALSE;
    }

    

    return TRUE;

    return CFrameWnd::OnCreateClient(lpcs, pContext);
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
    // 让视图第一次尝试该命令
// 	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
// 		return TRUE;

    //     if (m_3dView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
    //         return TRUE;

    // 否则，执行默认处理
    return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

    // 创建一个视图以占用框架的工作区
// 	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0),
//                           this, AFX_IDW_PANE_FIRST, NULL))
// 	{
// 		TRACE0("未能创建视图窗口\n");
// 		return -1;
// 	}

    // 创建一个视图以占用框架的工作区
//     if (!m_3dView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0),
//         this, AFX_IDW_PANE_FIRST, NULL))
//     {
//         TRACE0("未能创建视图窗口\n");
//         return -1;
//     }

    //m_baseWnd.Create(this, RGB(255, 255, 255), CRect(0, 0, 200, 800));

    SetIcon(m_hIcon, TRUE);
    SetIcon(m_hIconSmall, FALSE);

    return 0;
}

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// 将焦点前移到视图窗口
	//m_wndView.SetFocus();

    //m_3dView.SetFocus();
}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
    CFrameWnd::OnSize(nType, cx, cy);

//     if (m_wndStatusBar.IsWindowVisible())
//     {
//         CRect sbRect;
//         m_wndStatusBar.GetWindowRect(&sbRect);
// 
//         m_baseWnd.MoveWindow(0, 0, cx, cy - sbRect.Height(), TRUE);
//     }
//     else
//     {
//         m_baseWnd.MoveWindow(0, 0, cx, cy, TRUE);
//     }
}


