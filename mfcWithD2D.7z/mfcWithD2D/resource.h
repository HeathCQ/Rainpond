//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� mfcWithD2D.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define ID_DOCK_PANE                    129
#define IDR_mfcWithD2DTYPE              130
#define IDI_LOGO                        310
#define IDI_LOGO_SMALL                  311
#define IDB_LOGO                        312
#define IDB_LOGO_SMALL                  313
#define IDD_ADJUSTPANE                  314
#define IDC_SLIDER_CX                   1000
#define IDC_SLIDER_CY                   1001
#define IDC_SLIDER_CZ                   1002
#define IDC_SLIDER_ROTX                 1003
#define IDC_SLIDER_ZAXISROTANGLE        1004
#define IDC_SLIDER_ROTY                 1005
#define IDC_SLIDER6                     1006
#define IDC_SLIDER_ROTZ                 1006
#define IDC_STA_SEPARATOR               1007
#define IDC_STA_SHOW_ZAXISROTANGLE      1008
#define IDC_SLIDER_XAXISROTANGLE        1009
#define IDC_STA_SHOW_XAXISROTANGLE      1010
#define IDC_SLIDER_YAXISROTANGLE        1011
#define IDC_STA_SHOW_YAXISROTANGLE      1012
#define IDC_BTN_DEFAULT                 1013
#define IDC_BTN_PERSPECTIVE             1014
#define IDC_BTN_PERSPECTIVE_PROJECTION  1014
#define IDC_STA_SHOW_ZROTATION          1015
#define IDC_STA_SHOW_YROTATION          1016
#define IDC_STA_SHOW_XROTATION          1017
#define IDC_STA_SHOW_CZ                 1018
#define IDC_STA_SHOW_CY                 1019
#define IDC_STA_SHOW_CX                 1020
#define IDC_BTN_DEFAULT_PERSPECTIVE_PARAMETER 1021
#define IDC_BTN_PARALLEL_PROJECTION     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        317
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           315
#endif
#endif
