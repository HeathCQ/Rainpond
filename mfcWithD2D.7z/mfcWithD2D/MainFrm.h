
// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once

#include "ChildView.h"
#include "ThreeDView.h"
#include "AdjustPane.h"
#include "QxDockPane.h"
#include "QxBaseWnd.h"

class CMainFrame : public CFrameWnd
{
    DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
    virtual ~CMainFrame();
	
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);

protected:
    CQxDockPane   m_dockPane;
	CChildView    m_wndView;
    //CThreeDView   m_3dView;
    CQBaseWnd     m_baseWnd;

public:
    CSplitterWndEx m_splitWnd;


protected:
    HICON m_hIcon;
    HICON m_hIconSmall;

protected:
    DECLARE_MESSAGE_MAP()
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
    afx_msg void OnSize(UINT nType, int cx, int cy);
};


