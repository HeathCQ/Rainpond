
// ChildView.h : CChildView ��Ľӿ�
//


#pragma once

class CChildView : public CWnd
{
public:
	CChildView();
    virtual ~CChildView();

protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
protected:
    DECLARE_MESSAGE_MAP()
    afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnDestroy();
	afx_msg void OnPaint();
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
    afx_msg void OnFileOpen();
    afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
    afx_msg void OnSetFocus(CWnd* pOldWnd);
    afx_msg void OnKillFocus(CWnd* pNewWnd);
	
protected:
    void DisplayBitmap(CDC *pDestDC, CDC *pSourDC, UINT nResourceID);
    void DisplayBitmap(CDC *pDestDC, CDC *pSourDC, LPCTSTR lpszPath);
    void DrawBitmap(CDC *pDestDC, CDC *pSourDC, CBitmap *pBitmap);
    void DisplayImage(LPCTSTR lpszImagePath);

protected:
    LPCTSTR m_lpszImagePath;

    float m_Scale;

    CString m_Text;

    HBITMAP qxLoadBitmap(LPCTSTR lpszPathName);
    HICON qxLoadIcon(LPCTSTR lpszPathName);
    HCURSOR qxLoadCursor(LPCTSTR lpszPathName);
    void Redraw(LPRECT lpRect = NULL, BOOL bErase = 1);
};

