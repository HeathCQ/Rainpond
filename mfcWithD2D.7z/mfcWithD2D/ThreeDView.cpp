
// ThreeDView.cpp : CThreeDView ���ʵ��
//

#include "stdafx.h"
#include "mfcWithD2D.h"
#include "ThreeDView.h"
#include "AdjustPane.h"


int CThreeDView::s_objectCount = 0;

ID2D1Factory* CThreeDView::s_factory = NULL;
IDWriteFactory* CThreeDView::s_writeFactory = NULL;
bool CThreeDView::s_d2dInitialzied = false;


static UINT32 ColorRGB(COLORREF clr)
{
    UINT32 rgb;

    BYTE r = clr & 0xFF;
    BYTE g = (clr & 0xFF00) >> 8;
    BYTE b = (clr & 0xFF0000) >> 16;

    rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return rgb;
}

static UINT32 ColorRGB(BYTE r, BYTE g, BYTE b)
{
    return (UINT32)(((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));
}

static D2D1::ColorF ColorRGBA(COLORREF clr, FLOAT alpha = 10.0F)
{
    UINT32 rgb;

    BYTE r = clr & 0xFF;
    BYTE g = (clr & 0xFF00) >> 8;
    BYTE b = (clr & 0xFF0000) >> 16;

    rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return D2D1::ColorF::ColorF(clr, alpha);
}

static D2D1::ColorF ColorRGBA(BYTE r, BYTE g, BYTE b, FLOAT alpha = 10.0F)
{
    UINT32 rgb = (((BYTE)(b) | ((WORD)((BYTE)(g)) << 8)) | (((DWORD)(BYTE)(r)) << 16));

    return D2D1::ColorF::ColorF(rgb, alpha);
}


// CThreeDView


IMPLEMENT_DYNCREATE(CThreeDView, CView)


// CThreeDView ����/��������

CThreeDView::CThreeDView()
{
    s_objectCount++;

    InitDirect2D();

    // ����б������ͼ��б�Ƕȣ������ƣ�
    SetSlantRadian(M_PI / 4);

    // ���ù�ģ����
    SetScale(80);

    // ��������ϵ��x��y�����λ�ƣ����ı��ģ����£����ƶ����أ�
    SetTransformOrigin(600, 400);

    // ��������뾶radius��ȡ������stepPhi��stepTheta
    SetPlotSphere(2.0, 0.01, 0.1);

    m_bLButtonDown = false;
    m_bRButtonDown = false;

    origin = CPoint(600, 400);

    scale = 1.0f;

    xRotate = 0.0f;
    yRotate = 0.0f;
    zRotate = 0.0f;

    deltaX = 0.0f;
    deltaY = 0.0f;
    deltaZ = 0.0f;

    m_bShowPerspective = true;
   
    InitCameraParameter();

    SetBox();

    InitParallelProjectionParameter();

    SetBox2();

}

CThreeDView::~CThreeDView()
{
    // ʵ�������1

    s_objectCount--;

    // ��������Դ

    if (s_objectCount == 0)
    {
        ReleaseDirect2D();
    }
}

// CThreeDView �麯��

BOOL CThreeDView::PreCreateWindow(CREATESTRUCT& cs)
{
    if (!CWnd::PreCreateWindow(cs))
        return FALSE;

    cs.style &= ~WS_BORDER;

    cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

    return TRUE;
}

// CThreeDView ��Ϣ��������

BEGIN_MESSAGE_MAP(CThreeDView, CWnd)
    ON_WM_CREATE()
    ON_WM_DESTROY()
    ON_WM_PAINT()
    ON_WM_ERASEBKGND()
    ON_WM_SIZE()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_RBUTTONDOWN()
    ON_WM_RBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_MOUSEWHEEL()
    ON_WM_ACTIVATE()
    ON_WM_SETFOCUS()
    ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

// CThreeDView ��Ϣӳ��

int CThreeDView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CWnd::OnCreate(lpCreateStruct) == -1)
        return -1;

    // TODO:  �ڴ�������ר�õĴ�������
 
    if (!InitD2dResoureces())
    {
        return -1;
    }

    return 0;
}

void CThreeDView::OnDestroy()
{
    CWnd::OnDestroy();

    ReleaseD2dResources();
}

void CThreeDView::OnPaint()
{
    //GdiDraw();

    D2dDraw();
}

BOOL CThreeDView::OnEraseBkgnd(CDC* pDC)
{
    //return CWnd::OnEraseBkgnd(pDC);

    return TRUE;
}

void CThreeDView::OnSize(UINT nType, int cx, int cy)
{
    CWnd::OnSize(nType, cx, cy);

    // TODO: �ڴ˴�������Ϣ�����������

    UpdateView();
}

void CThreeDView::OnLButtonDown(UINT nFlags, CPoint point)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

    m_LButtonDownPoint = point;

    m_bLButtonDown = true;

    SetCapture();

    CWnd::OnLButtonDown(nFlags, point);
}

void CThreeDView::OnLButtonUp(UINT nFlags, CPoint point)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

    m_bLButtonDown = false;

    ::ReleaseCapture();

    CWnd::OnLButtonUp(nFlags, point);
}

void CThreeDView::OnRButtonDown(UINT nFlags, CPoint point)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

    m_bRButtonDown = true;

    m_RButtonDownPoint = point;

    SetCapture();

    CWnd::OnRButtonDown(nFlags, point);
}

void CThreeDView::OnRButtonUp(UINT nFlags, CPoint point)
{
    // TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

    m_bRButtonDown = false;

    ::ReleaseCapture();

    CWnd::OnRButtonUp(nFlags, point);
}

void CThreeDView::OnMouseMove(UINT nFlags, CPoint point)
{
    if (m_bLButtonDown)
    {
        origin.x += (point.x - m_LButtonDownPoint.x);
        origin.y += (point.y - m_LButtonDownPoint.y);

        UpdateView();

        m_LButtonDownPoint = point;
    }
    else if (m_bRButtonDown)
    {
        if (m_bShowPerspective)
        {

        }
        else
        {
            if ((nFlags & MK_CONTROL) != MK_CONTROL)
            {
                int spanx = abs(point.x - m_RButtonDownPoint.x);
                int spany = abs(point.y - m_RButtonDownPoint.y);

//                 if (spanx > spany)
//                 {
                    if (point.x > m_RButtonDownPoint.x)
                        xAxisRotAngle = RadianAdd(xAxisRotAngle, 0.1f, 0.0f, M_PI_X2);
                    else if (point.x < m_RButtonDownPoint.x)
                        xAxisRotAngle = RadianAdd(xAxisRotAngle, -0.1f, 0.0f, M_PI_X2);
//                }
//                 else if (spanx < spany)
//                 {
                    if (point.y > m_RButtonDownPoint.y)
                        zAxisRotAngle = RadianAdd(zAxisRotAngle, 0.1f, -M_PI_X2, 0.0f);
                    else if (point.y < m_RButtonDownPoint.y)
                        zAxisRotAngle = RadianAdd(zAxisRotAngle, -0.1f, -M_PI_X2, 0.0f);
//                }

                
            }
            else
            {
                if (point.x > m_RButtonDownPoint.x)
                    yAxisRotAngle = RadianAdd(yAxisRotAngle, 0.1f, 0.0f, M_PI_X2);
                else if (point.x < m_RButtonDownPoint.x)
                    yAxisRotAngle = RadianAdd(yAxisRotAngle, -0.1f, 0.0f, M_PI_X2);
            }

            m_RButtonDownPoint = point;

            CalcParallelProjectionMatrix();
            
            UpdateView();

            UpdateParallelProjectionPane();
        }
    }

    CWnd::OnMouseMove(nFlags, point);
}

BOOL CThreeDView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
    if (zDelta > 0)
    {
        if (scale > 0.01f)
        {
            scale *= 0.8f;

            if (!m_bShowPerspective)
            {
                meshGridStep = 100.0f / scale;
            }

            UpdateView();
        }
    }
    else
    {
        if (scale < 100000.0f)
        {
            scale *= 1.25f;

            if (!m_bShowPerspective)
            {
                meshGridStep = 100.0f / scale;
            }

            UpdateView();
        }
    }

    return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}


// �ⲿ���ýӿ�


void CThreeDView::UpdateView()
{
    InvalidateRect(NULL);
    UpdateWindow();
}


// CThreeDView ����������


// ���ù�ģ
void CThreeDView::SetScale(float scale)
{
    this->scale = scale;
}

// ��������ϵԭ����x��y�����λ�ƣ����ı��ģ����£����ƶ����أ�
void CThreeDView::SetTransformOrigin(float transformOriginX, float transformOriginY)
{
    this->transformOriginX = transformOriginX;
    this->transformOriginY = transformOriginY;
}

// ��������뾶radius��ȡ������stepPhi��stepTheta
void CThreeDView::SetPlotSphere(float radius, float stepPhi, float stepTheta)
{
    this->radius = radius;
    this->stepPhi = stepPhi;
    this->stepTheta = stepTheta;
}

// ����б������ͼ����б�ǣ���λ���ȣ�
void CThreeDView::SetSlantRadian(float slant)
{
    this->slant = slant;
}

// ����
float CThreeDView::Scale(float val)
{
    return val * scale;
}

// �任����ϵX�͹�ģ
float CThreeDView::ScaleX(float x)
{
    return Scale(x);
}

// �任����ϵY�͹�ģ
float CThreeDView::ScaleY(float y)
{
    return -Scale(y);
}

// ʹ��б������ͼ������ά�����ת��Ϊ��άƽ���ϵĵ�
void CThreeDView::Transform3Dto2D(float &x, float &y, float z)
{
    x = x - (z * cos(slant)) / 2;
    y = y - (z * sin(slant)) / 2;
}


void CThreeDView::Transform3D(float &x, float &y, float &z)
{
    ::Scale(x, y, z, scale);

    ::Rotation(x, y, z, xRotate, yRotate, zRotate);

    ::Translation(x, y, z, deltaX, deltaY, deltaZ);
}


/*
    ���ռ���ά�����ת��Ϊ��άƽ�������
*/
CPoint CThreeDView::qxTransform3Dto2D(float x, float y, float z)
{
    float standX = 0.0f;
    float standY = 0.0f;
    float standZ = 0.0f;

    CPoint point2D;

    //point2D.x = x * cos(xAngleView) - ;


    Transform3Dto2D(standX, standY, standZ);

    return CPoint(standX, standY);
    
}

void CThreeDView::TransformLocalToWorld(_3dPoint3F &P)
{
    //Scale(P, 16.0f);

//     Rotation(P, xRotate, yRotate, zRotate);
// 
//     Translation(P, deltaX, deltaY, deltaZ);

    DirectX::XMFLOAT4 v(P.x, P.y, P.z, 1);

    DirectX::XMFLOAT4 ret = VectorMultiplyMatrix(v, localToWorldMatrix);

    P.x = v.x;
    P.y = v.y;
    P.z = v.z;
}

void CThreeDView::TransformWorldToCamera(_3dPoint3F &P)
{
    //Scale(P, scale);

//     Translation(P, -cameraCx, -cameraCy, -cameraCz);
// 
//     Rotation(P, -cameraRotx, -cameraRoty, -cameraRotz);

    DirectX::XMFLOAT4 v(P.x, P.y, P.z, 1);

    DirectX::XMFLOAT4 ret = VectorMultiplyMatrix(v, worldToCameraMatrix);

    P.x = ret.x;
    P.y = ret.y;
    P.z = ret.z;
}

void CThreeDView::TransformCameraToPixel(_3dPoint3F &P, D2D1_POINT_2F &U)
{
    U.x =  (-cameraFocalLength) * (P.x / P.z);
    U.y = -(-cameraFocalLength) * (P.y / P.z);
}

void CThreeDView::TransformLocalToPixel(_3dPoint3F &P, D2D1_POINT_2F &U)
{
    TransformLocalToWorld(P);
    TransformWorldToCamera(P);
    TransformCameraToPixel(P, U);

    U.x *= 200;
    U.y *= 200;
}

void CThreeDView::CalcLocalToWorldMatrix()
{
    float cosz = cos(zRotate);
    float sinz = sin(zRotate);
    DirectX::XMMATRIX matRotz
    (
        cosz, sinz, 0, 0,
        -sinz, cosz, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    );

    float cosx = cos(xRotate);
    float sinx = sin(xRotate);
    DirectX::XMMATRIX matRotx
    (
        1, 0, 0, 0,
        0, cosx, sinx, 0,
        0, -sinx, cosx, 0,
        0, 0, 0, 1
    );

    float cosy = cos(yRotate);
    float siny = sin(yRotate);
    DirectX::XMMATRIX matRoty
    (
        cosy, 0, -siny, 0,
        0, 1, 0, 0,
        siny, 0, cosy, 0,
        0, 0, 0, 1
    );


    DirectX::XMMATRIX matRot =  matRotx * matRoty * matRotz;

    DirectX::XMMATRIX matTrans(
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        deltaX, deltaY, deltaZ, 1
    );

    localToWorldMatrix = matRot * matTrans;
}

void CThreeDView::CalcWorldToCameraMatrix()
{
    DirectX::XMMATRIX matTrans
    (
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        -cameraCx, -cameraCy, -cameraCz, 1
    );

    float cosz = cos(-cameraRotz);
    float sinz = sin(-cameraRotz);
    DirectX::XMMATRIX matRotz
    (
        cosz, sinz, 0, 0,
        -sinz, cosz, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    );

    float cosy = cos(-cameraRoty);
    float siny = sin(-cameraRoty);
    DirectX::XMMATRIX matRoty
    (
        cosy, 0, -siny, 0,
        0,    1, 0,     0,
        siny, 0, cosy,  0,
        0, 0, 0, 1
    );

    float cosx = cos(-cameraRotx);
    float sinx = sin(-cameraRotx);
    DirectX::XMMATRIX matRotx
    (
        1, 0, 0, 0,
        0, cosx, sinx, 0,
        0, -sinx, cosx, 0,
        0, 0, 0, 1
    );

    DirectX::XMMATRIX matRot = matRotz * matRoty * matRotx;

    worldToCameraMatrix = matTrans * matRot;
}

void CThreeDView::GdiDraw()
{
    CPaintDC dc(this);

    CRect clientRect;
    GetClientRect(&clientRect);

    CRect gdiRect = clientRect;

    CDC mdc;
    CBitmap mbmp;
    mdc.CreateCompatibleDC(&dc);
    mbmp.CreateCompatibleBitmap(&dc, gdiRect.Width(), gdiRect.Height());
    mdc.SelectObject(&mbmp);

    mdc.FillSolidRect(&gdiRect, RGB(213, 238, 253));

    CPoint savedPoint = mdc.SetViewportOrg(origin);

    DrawAxis(mdc);
    DrawFuncCurve(mdc);
    //DrawTriangularPyramid(mdc);

    mdc.SetViewportOrg(savedPoint);

    dc.BitBlt(0, 0, gdiRect.Width(), gdiRect.Height(), &mdc, 0, 0, SRCCOPY);

    mbmp.DeleteObject();
    mdc.DeleteDC();
}

void CThreeDView::DrawAxis(CDC &mdc)
{
    float x, y, z;

    // -------------------- ��������ϵ -------------------------

    // ����x��

    mdc.MoveTo(ScaleX(0), ScaleY(0));
    mdc.LineTo(ScaleX(radius + 2), ScaleY(0));
    // ����x��ļ�ͷ
    mdc.MoveTo(ScaleX(radius + 1.8), ScaleY(0.2));
    mdc.LineTo(ScaleX(radius + 2), ScaleY(0));
    mdc.LineTo(ScaleX(radius + 1.8), ScaleY(-0.2));

    // ����y��

    mdc.MoveTo(ScaleX(0), ScaleY(0));
    mdc.LineTo(ScaleX(0), ScaleY(radius + 2));
    // ����y��ļ�ͷ
    mdc.MoveTo(ScaleX(-0.2), ScaleY(radius + 1.8));
    mdc.LineTo(ScaleX(0), ScaleY(radius + 2));
    mdc.LineTo(ScaleX(0.2), ScaleY(radius + 1.8));

    // ����z��

    x = 0.0f, y = 0.0f;
    Transform3Dto2D(x, y, radius + 5);
    mdc.MoveTo(ScaleX(0), ScaleY(0));
    mdc.LineTo(ScaleX(x), ScaleY(y));
    // ����z��ļ�ͷ
    x = 0.0f, y = 0.2f;
    Transform3Dto2D(x, y, radius + 5 - 0.2f);
    mdc.MoveTo(ScaleX(x), ScaleY(y));
    x = 0.0f, y = 0.0f;
    Transform3Dto2D(x, y, radius + 5);
    mdc.LineTo(ScaleX(x), ScaleY(y));
    x = 0.2f, y = 0.0f;
    Transform3Dto2D(x, y, radius + 5 - 0.2f);
    mdc.LineTo(ScaleX(x), ScaleY(y));

    // -------------------- ���ƿ̶��� -------------------------

    // ����x��̶���
    for (float scaleX = 0.2; scaleX < radius + 1; scaleX += 0.2)
    {
        mdc.MoveTo((int)ScaleX(scaleX), (int)ScaleY(0));
        mdc.LineTo((int)ScaleX(scaleX), (int)ScaleY(0.1));
    }

    // ����y��̶���
    for (float scaleY = 0.2; scaleY <= radius + 1; scaleY += 0.2)
    {
        mdc.MoveTo((int)ScaleX(0), (int)ScaleY(scaleY));
        mdc.LineTo((int)ScaleX(0.1), (int)ScaleY(scaleY));
    }

    // ����z��̶���
    for (float x = 0, y = 0, scaleZ = 0.2; scaleZ <= radius + 4; scaleZ += 0.2, x = 0, y = 0)
    {
        Transform3Dto2D(x, y, scaleZ);
        mdc.MoveTo((int)ScaleX(x), (int)ScaleY(y));
        mdc.LineTo((int)ScaleX(x + 0.1), (int)ScaleY(y));
    }

    // -------------------- �������� -------------------------

    // ����x���x
    mdc.TextOut(ScaleX(radius + 1.6), ScaleY(-0.2), CString("x"));
    // ����y���y
    mdc.TextOut(ScaleX(-0.2), ScaleY(radius + 1.6), CString("y"));
    // ����z���z
    x = 0.2, y = 0;
    Transform3Dto2D(x, y, radius + 5 - 0.4);
    mdc.TextOut(ScaleX(x), ScaleY(y), CString("z"));

    CString s;
    // ����x��̶�����
    for (float ScaleTextX = 0.4; ScaleTextX < radius + 1; ScaleTextX += 0.4)
    {
        s.Format(_T("%.1f"), ScaleTextX);
        mdc.TextOutW(ScaleX(ScaleTextX - 0.1), ScaleY(-0.1), s);
    }

    // ����y��̶�����
    for (float ScaleTextY = 0.4; ScaleTextY <= radius + 1; ScaleTextY += 0.4)
    {
        s.Format(_T("%.1f"), ScaleTextY);
        mdc.TextOutW(ScaleX(-0.4), ScaleY(ScaleTextY + 0.1), s);
    }

    // ����z��̶�����
    for (float ScaleTextZ = 0.6; ScaleTextZ <= radius + 4; ScaleTextZ += 0.6)
    {
        s.Format(_T("%.1f"), ScaleTextZ);
        x = 0, y = 0;
        Transform3Dto2D(x, y, ScaleTextZ);
        mdc.TextOutW(ScaleX(x + 0.15), ScaleY(y + 0.12), s);
    }
}

void CThreeDView::DrawFuncCurve(CDC &mdc)
{
    float x, y, z;

    // ���ƺ���ͼ��Title
    x = 0, y = 0;
    Transform3Dto2D(x, y, radius + 5);
    mdc.TextOutW(ScaleX(x + 3), ScaleY(y), CString("x^2 + y^2 + z^2 = r^2"));

    // -------------------- ���ƺ��� -------------------------

    // ����
    float phi, theta;
    for (phi = 0; phi < 2 * M_PI; phi += stepPhi)
    {
        for (theta = 0; theta < M_PI; theta += stepTheta)
        {
            x = radius * sin(phi) * cos(theta);
            y = radius * sin(phi) * sin(theta);
            z = radius * cos(phi);

            Transform3Dto2D(x, y, z);

            srand(z);
            mdc.SetPixel(ScaleX(x), ScaleY(y), RGB(rand() % 255, rand() % 255, rand() % 255));
        }
    }

}

void CThreeDView::DrawTriangularPyramid(CDC &mdc)
{
    float x, y, z;

    //// ����׶�������ã�
    x = 1, y = 0, z = 0;
    Transform3Dto2D(x, y, z);
    mdc.MoveTo((int)ScaleX(x), (int)ScaleY(y));

    x = 0, y = 1, z = 0;
    Transform3Dto2D(x, y, z);
    mdc.LineTo((int)ScaleX(x), (int)ScaleY(y));

    x = 0, y = 0, z = 1;
    Transform3Dto2D(x, y, z);
    mdc.LineTo((int)ScaleX(x), (int)ScaleY(y));

    x = 1, y = 0, z = 0;
    Transform3Dto2D(x, y, z);
    mdc.LineTo((int)ScaleX(x), (int)ScaleY(y));

}


bool CThreeDView::InitDirect2D()
{
    if (s_d2dInitialzied)
        return true;

    if (FAILED(CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE)))
    {
        return false;
    }

    if (FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &s_factory)))
    {
        return false;
    }

    if (FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,
                                   __uuidof(s_writeFactory),
                                   reinterpret_cast<IUnknown **>(&s_writeFactory))))
    {
        return false;
    }
    
    s_d2dInitialzied = true;

    return true;
}

void CThreeDView::ReleaseDirect2D()
{
    if (s_factory)
    {
        s_factory->Release();
        s_factory = NULL;
    }

    if (s_writeFactory)
    {
        s_writeFactory->Release();
        s_writeFactory = NULL;
    }

    s_d2dInitialzied = false;
}

bool CThreeDView::InitD2dResoureces()
{
    if (!s_d2dInitialzied)
        return false;

    ASSERT(s_factory);
    ASSERT(s_writeFactory);

    D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
        D2D1_RENDER_TARGET_TYPE_DEFAULT,
        D2D1::PixelFormat(
            DXGI_FORMAT_B8G8R8A8_UNORM,
            D2D1_ALPHA_MODE_IGNORE),
        0,
        0,
        D2D1_RENDER_TARGET_USAGE_NONE,
        D2D1_FEATURE_LEVEL_DEFAULT
    );

    if (FAILED(s_factory->CreateDCRenderTarget(&props, &m_dcRender)))
    {
        return false;
    }

    m_dcRender->CreateSolidColorBrush(ColorRGBA(0, 0, 0), &m_brush);
    m_dcRender->CreateSolidColorBrush(ColorRGBA(255, 0, 0), &m_brAxisX);
    m_dcRender->CreateSolidColorBrush(ColorRGBA(0, 255, 0), &m_brAxisY);
    m_dcRender->CreateSolidColorBrush(ColorRGBA(0, 0, 255), &m_brAxisZ);

    if (FAILED(s_factory->CreateStrokeStyle(D2D1::StrokeStyleProperties(
                                                    D2D1_CAP_STYLE_FLAT,
                                                    D2D1_CAP_STYLE_FLAT,
                                                    D2D1_CAP_STYLE_FLAT,
                                                    D2D1_LINE_JOIN_MITER,
                                                    10.0f,
                                                    D2D1_DASH_STYLE_SOLID,
                                                    0.0f),
                                            NULL,
                                            0,
                                            &m_strokeStyle)))
    {
        return false;
    }


    if (FAILED(s_writeFactory->CreateTextFormat(
                    L"Arial",
                    NULL,
                    DWRITE_FONT_WEIGHT_NORMAL,
                    DWRITE_FONT_STYLE_NORMAL,
                    DWRITE_FONT_STRETCH_NORMAL,
                    16.0f,
                    L"en-US",
                    &m_wtfAxis)))
    {
        return false;
    }

    return true;
}

void CThreeDView::ReleaseD2dResources()
{
    if (m_brush)
    {
        m_brush->Release();
        m_brush = NULL;
    }

    if (m_brAxisX)
    {
        m_brAxisX->Release();
        m_brAxisX = NULL;
    }

    if (m_brAxisY)
    {
        m_brAxisY->Release();
        m_brAxisY = NULL;
    }

    if (m_brAxisZ)
    {
        m_brAxisZ->Release();
        m_brAxisZ = NULL;
    }

    if (m_strokeStyle)
    {
        m_strokeStyle->Release();
        m_strokeStyle = NULL;
    }

    if (m_wtfAxis)
    {
        m_wtfAxis->Release();
        m_wtfAxis = NULL;
    }

    if (m_dcRender)
    {
        m_dcRender->Release();
        m_dcRender = NULL;
    }
}


void CThreeDView::D2dDraw()
{
    CPaintDC dc(this);

    CRect clientRect;
    GetClientRect(&clientRect);

    CRect d2dRect = clientRect;

    if (!m_dcRender)
        return;

    //m_dcRender->SetAntialiasMode(D2D1_ANTIALIAS_MODE_FORCE_DWORD);
    m_dcRender->BindDC(dc.m_hDC, &d2dRect);

    m_dcRender->BeginDraw();
    m_dcRender->SetTransform(D2D1::Matrix3x2F::Translation(origin.x, origin.y));
    m_dcRender->Clear(ColorRGBA(25, 53, 73));

    if (m_bShowPerspective)
    {
//      DrawAxis(m_dcRender);
//      DrawFuncCurve(m_dcRender);
//      DrawTriangularPyramid(m_dcRender);

        DrawAxisV2(m_dcRender);
        DrawFuncCurveV2(m_dcRender);
//      DrawPerspective(m_dcRender);
    }
    else
    {
        DrawParallelProjection(m_dcRender);
    }

    m_dcRender->EndDraw();
}

void CThreeDView::DrawAxis(ID2D1DCRenderTarget *render)
{
    float x, y, z;

    D2D1_POINT_2F originPoint = D2D1::Point2F(ScaleX(0), ScaleY(0));

    // -------------------- ��������ϵ -------------------------

    // ����x��

    D2D1_POINT_2F xStartPoint = D2D1::Point2F(-ScaleX(radius + 2), ScaleY(0));
    D2D1_POINT_2F xEndPoint = D2D1::Point2F(ScaleX(radius + 2), ScaleY(0));
    render->DrawLine(xStartPoint, xEndPoint, m_brAxisX, 1.0F, m_strokeStyle);
    // ����x��ļ�ͷ
    D2D1_POINT_2F p1 = D2D1::Point2F(ScaleX(radius + 1.8), ScaleY(0.2));
    D2D1_POINT_2F p2 = D2D1::Point2F(ScaleX(radius + 2), ScaleY(0));
    D2D1_POINT_2F p3 = D2D1::Point2F(ScaleX(radius + 1.8), ScaleY(-0.2));

    render->DrawLine(p1, p2, m_brAxisX, 1.0F, m_strokeStyle);
    render->DrawLine(p2, p3, m_brAxisX, 1.0F, m_strokeStyle);

    // ����y��

    D2D1_POINT_2F yStartPoint = D2D1::Point2F(ScaleX(0), ScaleY(radius + 2));
    D2D1_POINT_2F yEndPoint = D2D1::Point2F(ScaleX(0), -ScaleY(radius + 2));
    render->DrawLine(yStartPoint, yEndPoint, m_brAxisY, 1.0F, m_strokeStyle);
    // ����y��ļ�ͷ
    p1 = D2D1::Point2F(ScaleX(-0.2), ScaleY(radius + 1.8));
    p2 = D2D1::Point2F(ScaleX(0), ScaleY(radius + 2));
    p3 = D2D1::Point2F(ScaleX(0.2), ScaleY(radius + 1.8));

    render->DrawLine(p1, p2, m_brAxisY, 1.0F, m_strokeStyle);
    render->DrawLine(p2, p3, m_brAxisY, 1.0F, m_strokeStyle);

    // ����z��

    x = 0, y = 0;
    Transform3Dto2D(x, y, -(radius + 5));
    D2D1_POINT_2F zStartPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));
    x = 0, y = 0;
    Transform3Dto2D(x, y, radius + 5);
    D2D1_POINT_2F zEndPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));
    render->DrawLine(zStartPoint, zEndPoint, m_brAxisZ, 1.0F, m_strokeStyle);
    // ����z��ļ�ͷ
    x = 0, y = 0.2;
    Transform3Dto2D(x, y, radius + 5 - 0.2);
    p1 = D2D1::Point2F(ScaleX(x), ScaleY(y));
    x = 0, y = 0;
    Transform3Dto2D(x, y, radius + 5);
    p2 = D2D1::Point2F(ScaleX(x), ScaleY(y));
    x = 0.2, y = 0;
    Transform3Dto2D(x, y, radius + 5 - 0.2);
    p3 = D2D1::Point2F(ScaleX(x), ScaleY(y));

    render->DrawLine(p1, p2, m_brAxisZ, 1.0F, m_strokeStyle);
    render->DrawLine(p2, p3, m_brAxisZ, 1.0F, m_strokeStyle);

    // -------------------- ���ƿ̶��� -------------------------

    // ����x��̶���
//     for (float scaleX = 0.2; scaleX < radius + 1; scaleX += 0.2)
//     {
//         p1 = D2D1::Point2F(ScaleX(scaleX), ScaleY(0));
//         p2 = D2D1::Point2F(ScaleX(scaleX), ScaleY(0.1));
//         render->DrawLine(p1, p2, m_brAxisX, 1.0F, m_strokeStyle);
//     }
// 
//     // ����y��̶���
//     for (float scaleY = 0.2; scaleY <= radius + 1; scaleY += 0.2)
//     {
//         p1 = D2D1::Point2F(ScaleX(0), ScaleY(scaleY));
//         p2 = D2D1::Point2F(ScaleX(0.1), ScaleY(scaleY));
//         render->DrawLine(p1, p2, m_brAxisY, 1.0F, m_strokeStyle);
//     }
// 
//     // ����z��̶���
//     for (float x = 0, y = 0, scaleZ = 0.2; scaleZ <= radius + 4; scaleZ += 0.2, x = 0, y = 0)
//     {
//         Transform3Dto2D(x, y, scaleZ);
//         p1 = D2D1::Point2F(ScaleX(x), ScaleY(y));
//         p2 = D2D1::Point2F(ScaleX(x + 0.1), ScaleY(y));
//         render->DrawLine(p1, p2, m_brAxisZ, 1.0F, m_strokeStyle);
//     }

    // -------------------- �������� -------------------------

    CString text;
    D2D1_RECT_F layoutRect;

    // ����x���x
    text = L"X";
    layoutRect = D2D1::RectF(ScaleX(radius + 1.6), ScaleY(-0.2),
                             ScaleX(radius + 1.6) + 20.0f, ScaleY(-0.2) + 16.0f);
    render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisX);
    // ����y���y
    text = L"Y";
    layoutRect = D2D1::RectF(ScaleX(-0.2), ScaleY(radius + 1.6),
                             ScaleX(-0.2) + 20.0f, ScaleY(radius + 1.6) + 16.0f);
    render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisY);
    // ����z���z
    x = 0.2f, y = 0.0f;
    Transform3Dto2D(x, y, radius + 5 - 0.4);
    text = L"Z";
    layoutRect = D2D1::RectF(ScaleX(x), ScaleY(y),
                             ScaleX(x) + 20.0f, ScaleY(y) + 16.0f);
    render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisZ);

//     CString s;
//     // ����x��̶�����
//     for (float ScaleTextX = 0.4; ScaleTextX < radius + 1; ScaleTextX += 0.4)
//     {
//         s.Format(_T("%.1f"), ScaleTextX);
//         mdc.TextOutW(ScaleX(ScaleTextX - 0.1), ScaleY(-0.1), s);
//     }
// 
//     // ����y��̶�����
//     for (float ScaleTextY = 0.4; ScaleTextY <= radius + 1; ScaleTextY += 0.4)
//     {
//         s.Format(_T("%.1f"), ScaleTextY);
//         mdc.TextOutW(ScaleX(-0.4), ScaleY(ScaleTextY + 0.1), s);
//     }
// 
//     // ����z��̶�����
//     for (float ScaleTextZ = 0.6; ScaleTextZ <= radius + 4; ScaleTextZ += 0.6)
//     {
//         s.Format(_T("%.1f"), ScaleTextZ);
//         x = 0, y = 0;
//         Transform3Dto2D(x, y, ScaleTextZ);
//         mdc.TextOutW(ScaleX(x + 0.15), ScaleY(y + 0.12), s);
//     }
}

void CThreeDView::DrawFuncCurve(ID2D1DCRenderTarget *render)
{
    float x, y, z;

    // ���ƺ���ͼ��Title
    x = 0, y = 0;
    Transform3Dto2D(x, y, -(radius + 4));
    CString text = L"x^2 + y^2 + z^2 = r^2";
    D2D1_RECT_F layoutRect = D2D1::RectF(ScaleX(x), -ScaleY(y),
                                         ScaleX(x) + 200.0f, -ScaleY(y) + 16.0f);
    render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisZ);

    // -------------------- ���ƺ��� -------------------------

    D2D1_POINT_2F p1, p2;

    x = radius * sin(0) * cos(0);
    y = radius * sin(0) * sin(0);
    z = radius * cos(0);

    Transform3Dto2D(x, y, z);

    p1 = D2D1::Point2F(ScaleX(x), ScaleY(y));

    // ����
    float phi, theta;
    for (phi = 0; phi < 2 * M_PI; phi += stepPhi)
    {
        for (theta = 0; theta < M_PI; theta += stepTheta)
        {
            x = radius * sin(phi) * cos(theta);
            y = radius * sin(phi) * sin(theta);
            z = radius * cos(phi);

            Transform3Dto2D(x, y, z);

            p2 = D2D1::Point2F(ScaleX(x), ScaleY(y));

            render->DrawLine(p1, p2, m_brush, 0.1f, m_strokeStyle);

            p1 = p2;
        }
    }

}

void CThreeDView::DrawTriangularPyramid(ID2D1DCRenderTarget *render)
{
    float x, y, z;

    D2D1_POINT_2F startPoint, endPoint;

    //// ����׶�������ã�
    x = 1, y = 0, z = 0;
    Transform3Dto2D(x, y, z);
    startPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));

    x = 0, y = 1, z = 0;
    Transform3Dto2D(x, y, z);
    endPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));
    render->DrawLine(startPoint, endPoint, m_brush, 1.0F, m_strokeStyle);

    startPoint = endPoint;

    x = 0, y = 0, z = 1;
    Transform3Dto2D(x, y, z);
    endPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));
    render->DrawLine(startPoint, endPoint, m_brush, 1.0F, m_strokeStyle);

    startPoint = endPoint;

    x = 1, y = 0, z = 0;
    Transform3Dto2D(x, y, z);
    endPoint = D2D1::Point2F(ScaleX(x), ScaleY(y));
    render->DrawLine(startPoint, endPoint, m_brush, 1.0F, m_strokeStyle);
}

void CThreeDView::DrawAxisV2(ID2D1DCRenderTarget *render)
{
    _3dPoint3F P;
    D2D1_POINT_2F U1, U2;

    P.x = P.y = P.z = 0.0f;
    TransformLocalToPixel(P, U1);

    // -------------------- ��������ϵ -------------------------

    // ����x��

    P.x = 4.0f; P.y = P.z = 0.0f;
    TransformLocalToPixel(P, U2);

    render->DrawLine(U1, U2, m_brAxisX, 1.0F, m_strokeStyle);

    // ����x��ļ�ͷ
//     D2D1_POINT_2F p1 = D2D1::Point2F(ScaleX(radius + 1.8), ScaleY(0.2));
//     D2D1_POINT_2F p2 = D2D1::Point2F(ScaleX(radius + 2), ScaleY(0));
//     D2D1_POINT_2F p3 = D2D1::Point2F(ScaleX(radius + 1.8), ScaleY(-0.2));
// 
//     render->DrawLine(p1, p2, m_brAxisX, 1.0F, m_strokeStyle);
//     render->DrawLine(p2, p3, m_brAxisX, 1.0F, m_strokeStyle);

    // ����y��

    P.x = 0.0f; P.y = 4.0f; P.z = 0.0f;
    TransformLocalToPixel(P, U2);

    render->DrawLine(U1, U2, m_brAxisY, 1.0F, m_strokeStyle);
    // ����y��ļ�ͷ
//     p1 = D2D1::Point2F(ScaleX(-0.2), ScaleY(radius + 1.8));
//     p2 = D2D1::Point2F(ScaleX(0), ScaleY(radius + 2));
//     p3 = D2D1::Point2F(ScaleX(0.2), ScaleY(radius + 1.8));
// 
//     render->DrawLine(p1, p2, m_brAxisY, 1.0F, m_strokeStyle);
//     render->DrawLine(p2, p3, m_brAxisY, 1.0F, m_strokeStyle);

    // ����z��

    P.x = P.y = 0.0f, P.z = 4.0f;
    TransformLocalToPixel(P, U2);

    render->DrawLine(U1, U2, m_brAxisZ, 1.0F, m_strokeStyle);
    // ����z��ļ�ͷ
//     x = 0, y = 0.2;
//     Transform3Dto2D(x, y, radius + 5 - 0.2);
//     p1 = D2D1::Point2F(ScaleX(x), ScaleY(y));
//     x = 0, y = 0;
//     Transform3Dto2D(x, y, radius + 5);
//     p2 = D2D1::Point2F(ScaleX(x), ScaleY(y));
//     x = 0.2, y = 0;
//     Transform3Dto2D(x, y, radius + 5 - 0.2);
//     p3 = D2D1::Point2F(ScaleX(x), ScaleY(y));
// 
//     render->DrawLine(p1, p2, m_brAxisZ, 1.0F, m_strokeStyle);
//     render->DrawLine(p2, p3, m_brAxisZ, 1.0F, m_strokeStyle);

    // -------------------- ���ƿ̶��� -------------------------

    // ����x��̶���
    //     for (float scaleX = 0.2; scaleX < radius + 1; scaleX += 0.2)
    //     {
    //         p1 = D2D1::Point2F(ScaleX(scaleX), ScaleY(0));
    //         p2 = D2D1::Point2F(ScaleX(scaleX), ScaleY(0.1));
    //         render->DrawLine(p1, p2, m_brAxisX, 1.0F, m_strokeStyle);
    //     }
    // 
    //     // ����y��̶���
    //     for (float scaleY = 0.2; scaleY <= radius + 1; scaleY += 0.2)
    //     {
    //         p1 = D2D1::Point2F(ScaleX(0), ScaleY(scaleY));
    //         p2 = D2D1::Point2F(ScaleX(0.1), ScaleY(scaleY));
    //         render->DrawLine(p1, p2, m_brAxisY, 1.0F, m_strokeStyle);
    //     }
    // 
    //     // ����z��̶���
    //     for (float x = 0, y = 0, scaleZ = 0.2; scaleZ <= radius + 4; scaleZ += 0.2, x = 0, y = 0)
    //     {
    //         Transform3Dto2D(x, y, scaleZ);
    //         p1 = D2D1::Point2F(ScaleX(x), ScaleY(y));
    //         p2 = D2D1::Point2F(ScaleX(x + 0.1), ScaleY(y));
    //         render->DrawLine(p1, p2, m_brAxisZ, 1.0F, m_strokeStyle);
    //     }

    // -------------------- �������� -------------------------

//     CString text;
//     D2D1_RECT_F layoutRect;
// 
//     // ����x���x
//     text = L"X";
//     layoutRect = D2D1::RectF(ScaleX(radius + 1.6), ScaleY(-0.2),
//         ScaleX(radius + 1.6) + 20.0f, ScaleY(-0.2) + 16.0f);
//     render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisX);
//     // ����y���y
//     text = L"Y";
//     layoutRect = D2D1::RectF(ScaleX(-0.2), ScaleY(radius + 1.6),
//         ScaleX(-0.2) + 20.0f, ScaleY(radius + 1.6) + 16.0f);
//     render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisY);
//     // ����z���z
//     x = 0.2f, y = 0.0f;
//     Transform3Dto2D(x, y, radius + 5 - 0.4);
//     text = L"Z";
//     layoutRect = D2D1::RectF(ScaleX(x), ScaleY(y),
//                              ScaleX(x) + 20.0f, ScaleY(y) + 16.0f);
//     render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisZ);

    //     CString s;
    //     // ����x��̶�����
    //     for (float ScaleTextX = 0.4; ScaleTextX < radius + 1; ScaleTextX += 0.4)
    //     {
    //         s.Format(_T("%.1f"), ScaleTextX);
    //         mdc.TextOutW(ScaleX(ScaleTextX - 0.1), ScaleY(-0.1), s);
    //     }
    // 
    //     // ����y��̶�����
    //     for (float ScaleTextY = 0.4; ScaleTextY <= radius + 1; ScaleTextY += 0.4)
    //     {
    //         s.Format(_T("%.1f"), ScaleTextY);
    //         mdc.TextOutW(ScaleX(-0.4), ScaleY(ScaleTextY + 0.1), s);
    //     }
    // 
    //     // ����z��̶�����
    //     for (float ScaleTextZ = 0.6; ScaleTextZ <= radius + 4; ScaleTextZ += 0.6)
    //     {
    //         s.Format(_T("%.1f"), ScaleTextZ);
    //         x = 0, y = 0;
    //         Transform3Dto2D(x, y, ScaleTextZ);
    //         mdc.TextOutW(ScaleX(x + 0.15), ScaleY(y + 0.12), s);
    //     }
}

void CThreeDView::DrawFuncCurveV2(ID2D1DCRenderTarget *render)
{

    // ���ƺ���ͼ��Title
//     x = 0, y = 0;
//     Transform3Dto2D(x, y, -(radius + 4));
//     CString text = L"x^2 + y^2 + z^2 = r^2";
//     D2D1_RECT_F layoutRect = D2D1::RectF(ScaleX(x), -ScaleY(y),
//         ScaleX(x) + 200.0f, -ScaleY(y) + 16.0f);
//     render->DrawText(text, text.GetLength(), m_wtfAxis, &layoutRect, m_brAxisZ);

    // -------------------- ���ƺ��� -------------------------

    _3dPoint3F P;

    D2D1_POINT_2F U1, U2;
    
    ID2D1SolidColorBrush *brTemp = NULL;

    P.x = radius * sin(0) * cos(0);
    P.y = radius * sin(0) * sin(0);
    P.z = radius * cos(0);

    TransformLocalToPixel(P, U1);

    // ����
    float phi, theta;
    for (phi = 0; phi < 2 * M_PI; phi += stepPhi)
    {
        for (theta = 0; theta < M_PI; theta += stepTheta)
        {
            P.x = radius * sin(phi) * cos(theta);
            P.y = radius * sin(phi) * sin(theta);
            P.z = radius * cos(phi);

            TransformLocalToPixel(P, U2);

            srand(P.x);

            if (SUCCEEDED(render->CreateSolidColorBrush(
                    ColorRGBA(rand() % 255, rand() % 255, rand() % 255), &brTemp)))
            {
                render->DrawLine(U1, U2, brTemp, 0.1f, m_strokeStyle);

                brTemp->Release();
                brTemp = NULL;
            }

            U1 = U2;
        }
    }

    if (brTemp)
    {
        brTemp->Release();
    }
}

void CThreeDView::DrawPerspective(ID2D1DCRenderTarget *render)
{
    D2D1_POINT_2F U[8];

    for (int i = 0; i < 8; i++)
    {
        _3dPoint3F P = box.points[i];

        // 1. ������ֲ�����ϵ�µĵ�Pת������������ϵ�µĵ�Pw

        // 2. ������������ϵת�������ϵ��ת�����󣬼��������������й�

        // 3. ����������ϵ�µĵ�Pwת�����������ϵ�µĵ�Pc

        // 4. ����͸��ͶӰ�任���󣬼�����������ڲ��й�

        // 5. ���������ϵ�µĵ�Pcִ��͸��ͶӰ�任��ת�������������(u,v)

        TransformLocalToPixel(P, U[i]);
    }

    render->DrawLine(U[0], U[1], m_brush);
    render->DrawLine(U[1], U[2], m_brush);
    render->DrawLine(U[2], U[3], m_brush);
    render->DrawLine(U[3], U[0], m_brush);

    render->DrawLine(U[4], U[5], m_brush);
    render->DrawLine(U[5], U[6], m_brush);
    render->DrawLine(U[6], U[7], m_brush);
    render->DrawLine(U[7], U[4], m_brush);

    render->DrawLine(U[0], U[4], m_brush);
    render->DrawLine(U[1], U[5], m_brush);
    render->DrawLine(U[2], U[6], m_brush);
    render->DrawLine(U[3], U[7], m_brush);
}

void CThreeDView::SetBox()
{
    box.p1 = { 1, -1, -1 };
    box.p2 = { -1, -1, -1 };
    box.p3 = { -1, -1, 1 };
    box.p4 = { 1, -1, 1 };
    box.p5 = { 1, 1, -1 };
    box.p6 = { -1, 1, -1 };
    box.p7 = { -1, 1, 1 };
    box.p8 = { 1, 1, 1 };
}

void CThreeDView::InitCameraParameter()
{
    cameraCx = 1.0f;
    cameraCy = 5.0f;
    cameraCz = 5.0f;

    cameraRotx = M_PI * 2 - M_PI / 5;
    cameraRoty = 0.0f;
    cameraRotz = 0.0f;

    cameraFocalLength = 0.5f;
    dx = 72.0f;
    dy = 72.0f;

    CalcLocalToWorldMatrix();

    CalcWorldToCameraMatrix();
}

void CThreeDView::InitParallelProjectionParameter()
{
    xAxisRotAngle = -35.26f * M_PI / 180.0f;
    yAxisRotAngle = 0.0f;// [0, 2 * pi)
    zAxisRotAngle = M_PI / 3;// ˳ʱ��[0, pi]

    meshGridStep = 100.0f / scale;

    CalcParallelProjectionMatrix();
}

void CThreeDView::CalcParallelProjectionMatrix()
{
    float cosz = cos(zAxisRotAngle);
    float sinz = sin(zAxisRotAngle);
    DirectX::XMMATRIX matRotZ
    (
        cosz, sinz, 0, 0,
        -sinz, cosz, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    );

    float cosx = cos(xAxisRotAngle);
    float sinx = sin(xAxisRotAngle);
    DirectX::XMMATRIX matRotx
    (
        1, 0, 0, 0,
        0, cosx, sinx, 0,
        0, -sinx, cosx, 0,
        0, 0, 0, 1
    );

    float cosy = cos(yAxisRotAngle);
    float siny = sin(yAxisRotAngle);
    DirectX::XMMATRIX matRoty
    (
        cosy, 0, -siny, 0,
        0, 1, 0, 0,
        siny, 0, cosy, 0,
        0, 0, 0, 1
    );

    DirectX::XMMATRIX matProjXOZ
    (
        1, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1
    );

    parallelProjectionMatrix =  matRotZ *matRotx * matRoty * matProjXOZ;
}

void CThreeDView::UpdateParallelProjectionPane()
{
    CSplitterWndEx *splitWnd = (CSplitterWndEx *)GetParent();
    CAdjustPane *adjustPane = (CAdjustPane *)splitWnd->GetPane(0, 1);

    if (adjustPane && adjustPane->GetSafeHwnd())
    {
        adjustPane->InitParallelProjectionPane();
    }
}

void CThreeDView::SetBox2()
{
    box2.p1 = { 100, -100, -100 };
    box2.p2 = { -100, -100, -100 };
    box2.p3 = { -100, -100, 100 };
    box2.p4 = { 100, -100, 100 };
    box2.p5 = { 100, 100, -100 };
    box2.p6 = { -100, 100, -100 };
    box2.p7 = { -100, 100, 100 };
    box2.p8 = { 100, 100, 100 };
}

void CThreeDView::ParallelProjection(_3dPoint3F &P, D2D1_POINT_2F &U)
{
    DirectX::XMFLOAT4 v(P.x, P.y, P.z, 1);

    DirectX::XMFLOAT4 ret = VectorMultiplyMatrix(v, parallelProjectionMatrix);

    U.x = ret.x * scale;
    U.y = -ret.z * scale;
}

void CThreeDView::DrawParallelProjection(ID2D1DCRenderTarget *render)
{
    _3dPoint3F P;
    D2D1_POINT_2F u1, u2, u3;

    ID2D1SolidColorBrush *brTemp = NULL;

    // ����������

    float xAxisEnd = 320.0f;
    float yAxisEnd = 320.0f;
    float zAxisEnd = 320.0f;

    P.x = P.y = P.z = 0.0f;
    ParallelProjection(P, u1);

    P.x = xAxisEnd;  P.y = P.z = 0.0f;
    ParallelProjection(P, u2);
    render->DrawLine(u1, u2, m_brAxisX, 1.0f, m_strokeStyle);

    P.x = 0.0f;  P.y = yAxisEnd; P.z = 0.0f;
    ParallelProjection(P, u2);
    render->DrawLine(u1, u2, m_brAxisY, 1.0f, m_strokeStyle);

    P.x = P.y = 0.0f; P.z = zAxisEnd;
    ParallelProjection(P, u2);
    render->DrawLine(u1, u2, m_brAxisZ, 1.0f, m_strokeStyle);

    // �����������ͷ

    float arrowLength = 10.0f / scale;
    float arrowWidth = 8.0f / scale;
    // x-axis arrow
    P.x = xAxisEnd - arrowLength;  P.y = 0.0f;  P.z = arrowWidth;
    ParallelProjection(P, u1);
    P.x = xAxisEnd;  P.y = P.z = 0.0f;
    ParallelProjection(P, u2);
    P.x = xAxisEnd - arrowLength;  P.y = 0.0f;  P.z = -arrowWidth;
    ParallelProjection(P, u3);
    render->DrawLine(u1, u2, m_brAxisX, 2.0f, m_strokeStyle);
    render->DrawLine(u2, u3, m_brAxisX, 2.0f, m_strokeStyle);
    // y-axis arrow
    P.x = 0.0f;  P.y = yAxisEnd - arrowLength;  P.z = arrowWidth;
    ParallelProjection(P, u1);
    P.x = 0.0f;  P.y = yAxisEnd; P.z = 0.0f;
    ParallelProjection(P, u2);
    P.x = -arrowWidth;  P.y = yAxisEnd - arrowLength;  P.z = -arrowWidth;
    ParallelProjection(P, u3);
    render->DrawLine(u1, u2, m_brAxisY, 2.0f, m_strokeStyle);
    render->DrawLine(u1, u2, m_brAxisY, 2.0f, m_strokeStyle);
    // z-axis arrow
    P.x = arrowWidth;  P.y = arrowWidth;  P.z = zAxisEnd - arrowLength;
    ParallelProjection(P, u1);
    P.x = P.y = 0.0f;  P.z = zAxisEnd;
    ParallelProjection(P, u2);
    P.x = -arrowWidth;  P.y = -arrowWidth;  P.z = zAxisEnd - arrowLength;
    ParallelProjection(P, u3);
    render->DrawLine(u1, u2, m_brAxisZ, 2.0f, m_strokeStyle);
    render->DrawLine(u1, u2, m_brAxisZ, 2.0f, m_strokeStyle);

    // ����ƽ������

    // ��֤StepEnd��meshGridStep��������
    float xAxisStepEnd = int(xAxisEnd / meshGridStep) * meshGridStep;
    float yAxisStepEnd = int(yAxisEnd / meshGridStep) * meshGridStep;
    float zAxisStepEnd = int(zAxisEnd / meshGridStep) * meshGridStep;

    // XOYƽ������
    for (float x = meshGridStep; x <= xAxisStepEnd; x += meshGridStep)
    {
        P.x = x; P.y = 0.0f; P.z = 0.0f;
        ParallelProjection(P, u1);
        P.x = x; P.y = yAxisStepEnd; P.z = 0.0f;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisX, 0.2f, m_strokeStyle);
    }
    for (float y = meshGridStep; y <= yAxisStepEnd; y += meshGridStep)
    {
        P.x = 0.0f; P.y = y; P.z = 0.0f;
        ParallelProjection(P, u1);
        P.x = xAxisStepEnd; P.y = y; P.z = 0.0f;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisX, 0.2f, m_strokeStyle);
    }
    // XOZƽ������
    for (float x = meshGridStep; x <= xAxisStepEnd; x += meshGridStep)
    {
        P.x = x; P.y = 0.0f; P.z = 0.0f;
        ParallelProjection(P, u1);
        P.x = x; P.y = 0.0f; P.z = zAxisStepEnd;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisZ, 0.2f, m_strokeStyle);
    }
    for (float z = meshGridStep; z <= zAxisStepEnd; z += meshGridStep)
    {
        P.x = 0.0f; P.y = 0.0f; P.z = z;
        ParallelProjection(P, u1);
        P.x = xAxisStepEnd; P.y = 0.0f; P.z = z;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisZ, 0.2f, m_strokeStyle);
    }
    // YOZƽ������
    for (float y = meshGridStep; y <= yAxisStepEnd; y += meshGridStep)
    {
        P.x = 0.0f; P.y = y; P.z = 0.0f;
        ParallelProjection(P, u1);
        P.x = 0.0f; P.y = y; P.z = zAxisStepEnd;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisY, 0.2f, m_strokeStyle);
    }
    for (float z = meshGridStep; z <= zAxisStepEnd; z += meshGridStep)
    {
        P.x = 0.0f; P.y = 0.0f; P.z = z;
        ParallelProjection(P, u1);
        P.x = 0.0f; P.y = yAxisStepEnd; P.z = z;
        ParallelProjection(P, u2);
        render->DrawLine(u1, u2, m_brAxisY, 0.2f, m_strokeStyle);
    }

    // ����������

    D2D1_POINT_2F U[8];

    for (int i = 0; i < 8; i++)
    {
        _3dPoint3F P = box2.points[i];

        ParallelProjection(P, U[i]);
    }

    render->DrawLine(U[0], U[1], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[1], U[2], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[2], U[3], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[3], U[0], m_brush, 2.0f, m_strokeStyle);

    render->DrawLine(U[4], U[5], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[5], U[6], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[6], U[7], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[7], U[4], m_brush, 2.0f, m_strokeStyle);
    
    render->DrawLine(U[0], U[4], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[1], U[5], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[2], U[6], m_brush, 2.0f, m_strokeStyle);
    render->DrawLine(U[3], U[7], m_brush, 2.0f, m_strokeStyle);


    // -------------------- �������� -------------------------
    // ���淽�̲������������ʾ

//     float radius = 200.0f;
//     float stepPhi = 0.01f;   // ��Z�����ת��  [0, 2 * PI)
//     float stepTheta = 0.1f;  // �����ϵ㵽Բ�ĵ�ֱ����Z��ļн� [0, PI)
// 
//     P.x = radius * sin(0) * cos(0);
//     P.y = radius * sin(0) * sin(0);
//     P.z = radius * cos(0);
// 
//     ParallelProjection(P, u1);
// 
//     for (float phi = 0.0f; phi < 2.0f * M_PI; phi += stepPhi)
//     {
//         for (float theta = 0.0f; theta < M_PI; theta += stepTheta)
//         {
//             P.x = radius * sin(phi) * cos(theta);
//             P.y = radius * sin(phi) * sin(theta);
//             P.z = radius * cos(phi);
// 
//             ParallelProjection(P, u2);
// 
//             srand(P.z);
// 
//             if (SUCCEEDED(render->CreateSolidColorBrush(
//                     ColorRGBA(rand() % 255, rand() % 255, rand() % 255), &brTemp)))
//             {
//                 render->DrawLine(u1, u2, brTemp, 0.1f, m_strokeStyle);
// 
//                 brTemp->Release();
//                 brTemp = NULL;
//             }
// 
//             u1 = u2;
//         }
//     }


    // -------------------- ����ƽ�� -------------------------
    // x + y + z = 100

    float radius = 200.0f;
    float stepPhi = 0.01f;   // ��Z�����ת��  [0, 2 * PI)
    float stepTheta = 0.1f;  // �����ϵ㵽Բ�ĵ�ֱ����Z��ļн� [0, PI)

    P = { -100.0f, -100.0f, 300.0f };
    ParallelProjection(P, u1);

    for (float x = -100.0f; x < 100.0f; x += 1.0f)
    {
        for (float y = -100.0f; y < 100.0f; y += 1.0f)
        {
            P.x = x;
            P.y = y;
            P.z = 100 - x - y;

            ParallelProjection(P, u2);
            render->DrawLine(u1, u2, m_brush, 0.1f, m_strokeStyle);

            u1 = u2;
        }
    }

    brTemp ? brTemp->Release() : 0;
}

void CThreeDView::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
    CWnd::OnActivate(nState, pWndOther, bMinimized);

    if (nState == WA_ACTIVE)
    {
        m_Text = _T("Activated");
    }
    else if (nState == WA_CLICKACTIVE)
    {
        m_Text = _T("Click Activated");
    }
    else if (nState == WA_INACTIVE)
    {
        m_Text = _T("InActivated");
    }

    InvalidateRect(NULL);
    UpdateWindow();
}


void CThreeDView::OnSetFocus(CWnd* pOldWnd)
{
    CWnd::OnSetFocus(pOldWnd);

    m_Text = _T("Focus On");

    InvalidateRect(NULL);
    UpdateWindow();
}


void CThreeDView::OnKillFocus(CWnd* pNewWnd)
{
    CWnd::OnKillFocus(pNewWnd);

    m_Text = _T("Lose Focus");

    InvalidateRect(NULL);
    UpdateWindow();
}
