#pragma once



// CAdjustPane ������ͼ

class CAdjustPane : public CFormView
{
	DECLARE_DYNCREATE(CAdjustPane)

protected:
	CAdjustPane();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CAdjustPane();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);  
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
    virtual void OnInitialUpdate();

protected:
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnBtnPerspectiveProjection();
    afx_msg void OnBtnParallelProjection();
    afx_msg void OnBtnDefaultPerspectiveParameter();
    afx_msg void OnBtnDefault();
    DECLARE_MESSAGE_MAP()

public:
    void InitPerspectiveProjectionPane();
    void InitParallelProjectionPane();
protected:
    void ShowSliderPosition(CSliderCtrl *sliderCtrl, CStatic *staticCtrl);
};


