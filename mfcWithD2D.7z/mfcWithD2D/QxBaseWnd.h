#pragma once

class CQBaseWnd : public CWnd
{
    DECLARE_DYNAMIC(CQBaseWnd)
private:
    CWnd *m_pWndParent;
    CRect m_rectWnd;
    COLORREF m_clrBackground;

public:
    CQBaseWnd(void);
    virtual ~CQBaseWnd(void);

    //��ʾ���� 
    BOOL ShowWnd();
    //���崴������ 
    BOOL Create(CWnd *pParentWnd, COLORREF clrBackground, CRect rectWnd);
    virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, 
                        DWORD dwStyle, const RECT& rect, CWnd* pParentWnd,
                        UINT nID, CCreateContext* pContext = NULL);
    virtual BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName,
                          DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam = NULL);
    //�رմ��� 
    BOOL Close();

private:
    //��Ӧ������Ϣ 
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    //��Ӧ�ػ���Ϣ 
    afx_msg void OnPaint();
    //�������� 
    BOOL CreateWnd(CWnd * pParentWnd = NULL);

protected:
    DECLARE_MESSAGE_MAP()
    //ע������ 
    virtual void PostNcDestroy();
};
