
// ThreeDView.h : CThreeDView ��Ľӿ�
//


#pragma once

#include "3dTransform.h"





struct Box
{
    Box() {}

    union
    {
        struct
        {
            _3dPoint3F p1;
            _3dPoint3F p2;
            _3dPoint3F p3;
            _3dPoint3F p4;
            _3dPoint3F p5;
            _3dPoint3F p6;
            _3dPoint3F p7;
            _3dPoint3F p8;
        };

        _3dPoint3F points[8];
    };

};


// CThreeDView ����

class CThreeDView : public CWnd
{
    DECLARE_DYNCREATE(CThreeDView)
    // ����
public:
    CThreeDView();
    virtual ~CThreeDView();

    // ��д
protected:
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

    // ���ɵ���Ϣӳ�亯��
protected:
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnDestroy();
    afx_msg void OnPaint();
    afx_msg BOOL OnEraseBkgnd(CDC* pDC);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
    DECLARE_MESSAGE_MAP()

public:
    void UpdateView();

    // ����������
public:
    void SetScale(float scale);
    void SetTransformOrigin(float transformOriginX, float transformOriginY);
    void SetPlotSphere(float radius, float stepPhi, float stepTheta);
    void SetSlantRadian(float slant);

    float Scale(float val);
    float ScaleX(float x);
    float ScaleY(float y);
    void Transform3Dto2D(float &x, float &y, float z);

    CPoint qxTransform3Dto2D(float x, float y, float z);
    
    void Transform3D(float &x, float &y, float &z);

    void TransformLocalToWorld(_3dPoint3F &P);
    void TransformWorldToCamera(_3dPoint3F &P);
    void TransformCameraToPixel(_3dPoint3F &P, D2D1_POINT_2F &U);
    void TransformLocalToPixel(_3dPoint3F &P, D2D1_POINT_2F &U);

    // ת������
protected:
    // ƽ��ͶӰ�任����
    DirectX::XMMATRIX localToWorldMatrix;
    // ����ת����任����
    DirectX::XMMATRIX worldToCameraMatrix;

    void CalcLocalToWorldMatrix();
    void CalcWorldToCameraMatrix();


    // ���������
protected:
    // ������ڲ�
    float cameraFocalLength;
    float dx;
    float dy;

    // ��������
    float cameraCx;
    float cameraCy;
    float cameraCz;
    float cameraRotx;
    float cameraRoty;
    float cameraRotz;

public:
    void SetCameraCx(float cx) {
        cameraCx = cx; 
        CalcWorldToCameraMatrix();
    }
    void SetCameraCy(float cy) { 
        cameraCy = cy; 
        CalcWorldToCameraMatrix();
    }
    void SetCameraCz(float cz) { 
        cameraCz = cz;
        CalcWorldToCameraMatrix();
    }
    void SetCameraRotx(float rotx) { 
        cameraRotx = rotx;
        CalcWorldToCameraMatrix();
    }
    void SetCameraRoty(float roty) { 
        cameraRoty = roty; 
        CalcWorldToCameraMatrix();
    }
    void SetCameraRotz(float rotz) { 
        cameraRotz = rotz; 
        CalcWorldToCameraMatrix();
    }
    float GetCameraCx() const { return cameraCx; }
    float GetCameraCy() const { return cameraCy; }
    float GetCameraCz() const { return cameraCz; }
    float GetCameraRotx() const { return cameraRotx; }
    float GetCameraRoty() const { return cameraRoty; }
    float GetCameraRotz() const { return cameraRotz; }

    /* ��ʼ���������������������ڲ�*/
    void InitCameraParameter();

    // ƽ��ͶӰ����
protected:
    float yAxisRotAngle;
    float zAxisRotAngle;
    float xAxisRotAngle;

    float meshGridStep;// ������ƽ���������
   
    // ƽ��ͶӰ�任����
    DirectX::XMMATRIX parallelProjectionMatrix;

public:
    void SetXAxisRotAngle(float rot) { 
        xAxisRotAngle = rot; 
        CalcParallelProjectionMatrix();
    }
    void SetZAxisRotAngle(float rot) { 
        zAxisRotAngle = rot; 
        CalcParallelProjectionMatrix();
    }
    void SetYAxisRotAngle(float rot) { 
        yAxisRotAngle = rot; 
        CalcParallelProjectionMatrix();
    }
    float GetXAxisRotAngle() const { return xAxisRotAngle; }
    float GetZAxisRotAngle() const { return zAxisRotAngle; }
    float GetYAxisRotAngle() const { return yAxisRotAngle; }
    void InitParallelProjectionParameter();
    void CalcParallelProjectionMatrix();
    void UpdateParallelProjectionPane();

protected:
    Box box2;

    void SetBox2();

    void ParallelProjection(_3dPoint3F &P, D2D1_POINT_2F &U);
    void DrawParallelProjection(ID2D1DCRenderTarget *render);

protected:
    bool m_bShowPerspective;

public:
    void SetShowPerspective(bool bShowPerspective) { 
        m_bShowPerspective = bShowPerspective; 
        UpdateView();
    }
    bool IsShowPerspective() const { return m_bShowPerspective; }

protected:
    float slant; // ��б��
    float radius, stepPhi, stepTheta;
    float transformOriginX, transformOriginY;

    bool m_bLButtonDown;
    bool m_bRButtonDown;

    CPoint m_LButtonDownPoint;
    CPoint m_RButtonDownPoint;

    CPoint origin;

    float scale; // ���ű���

    float xRotate;// ��X����ת�Ƕȣ������ƣ�[0, 2��)
    float yRotate;// ��Y����ת�Ƕȣ������ƣ�[0, 2��)
    float zRotate;// ��Z����ת�Ƕȣ������ƣ�[0, 2��)

    float deltaX; // ��X��λ��
    float deltaY; // ��Y��λ��
    float deltaZ; // ��Z��λ��


    // ��ͼʵ���������
protected:
    static int s_objectCount;

    // directx paint member
protected:
    static ID2D1Factory*     s_factory;
    static IDWriteFactory*   s_writeFactory;
    static bool              s_d2dInitialzied;
    ID2D1DCRenderTarget*     m_dcRender;
    ID2D1SolidColorBrush*    m_brush;
    ID2D1SolidColorBrush*    m_brAxisX;
    ID2D1SolidColorBrush*    m_brAxisY;
    ID2D1SolidColorBrush*    m_brAxisZ;
    ID2D1StrokeStyle*        m_strokeStyle;
    IDWriteTextFormat*       m_wtfAxis;


    static bool InitDirect2D();
    static void ReleaseDirect2D();

    bool InitD2dResoureces();
    void ReleaseD2dResources();


protected:
    void GdiDraw();
    void DrawAxis(CDC &mdc);
    void DrawFuncCurve(CDC &mdc);
    void DrawTriangularPyramid(CDC &mdc);

    void D2dDraw();
    void DrawAxis(ID2D1DCRenderTarget *render);
    void DrawFuncCurve(ID2D1DCRenderTarget *render);
    void DrawTriangularPyramid(ID2D1DCRenderTarget *render);

    void DrawAxisV2(ID2D1DCRenderTarget *render);
    void DrawFuncCurveV2(ID2D1DCRenderTarget *render);

    Box box;

    void SetBox();

    void DrawPerspective(ID2D1DCRenderTarget *render);

protected:
    CString m_Text;
    afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
    afx_msg void OnSetFocus(CWnd* pOldWnd);
    afx_msg void OnKillFocus(CWnd* pNewWnd);
};

