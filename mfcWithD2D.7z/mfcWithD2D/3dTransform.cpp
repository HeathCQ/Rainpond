#include "3dTransform.h"

#define _USE_MATH_DEFINES
#include <math.h>




void Translation(_3dPoint3F &P, float tx, float ty, float tz)
{
    P.x += tx;
    P.y += ty;
    P.z += tz;
}

void Rotation(_3dPoint3F &P, float rotx, float roty, float rotz)
{
    Rotation(P.x, P.y, P.z, rotx, roty, rotz);
}

void Scale(_3dPoint3F &P, float s)
{
    P.x *= s;
    P.y *= s;
    P.z *= s;
}

void Translation(
    float &x, float &y, float &z,
    float tx, float ty, float tz)
{
    x += tx;
    y += ty;
    z += tz;
}

void Rotation(
    float &x, float &y, float &z,
    float rotx, float toty, float rotz)
{
    float x_, y_, z_;
    float cos��, sin��;
    /*

    ��X����ת��
                      _                      _
                     |  1     0      0     0  |
      [x, y, z, 1] * |  0    cos��   sin��   0  |
                     |  0   -sin��   cos��   0  |
                     |_ 0     0      0     1 _|

    = [x, y*cos�� - z*sin��, y*sin�� + z*cos��, 1]

    */

    cos�� = cos(rotx);
    sin�� = sin(rotx);

    y_ = y * cos�� - z * sin��;
    z_ = y * sin�� + z * cos��;

    y = y_;
    z = z_;

    /*

    ��Y����ת��
                     _                      _
                    | cos��   0   -sin��    0  |
     [x, y, z, 1] * |  0     1     0      0  |
                    | sin��   0    con��    0  |
                    |_ 0     0     0      1 _|

    =[x*cos�� + z*sin��, y, -x*sin�� + z*cos��, 1]

    */

    cos�� = cos(toty);
    sin�� = sin(toty);

    x_ = x * cos�� + z * sin��;
    z_ = -x * sin�� + z * cos��;

    x = x_;
    z = z_;

    /*

    ��Z����ת��
                     _                     _
                    | cos��  sin��    0    0  |
     [x, y, z, 1] * |-sin��  cos��    0    0  |
                    |  0     0      1    0  |
                    |_ 0     0      0    1 _|

    =[x*cos�� - y*sin��, x*sin�� + y*cos��, z, 1]

    */

    cos�� = cos(rotz);
    sin�� = sin(rotz);

    x_ = x * cos�� - y * sin��;
    y_ = x * sin�� + y * cos��;

    x = x_;
    y = y_;
}

void Scale(float &x, float &y, float &z, float scale)
{
    x *= scale;
    y *= scale;
    z *= scale;
}

DirectX::XMFLOAT4 VectorMultiplyMatrix(const DirectX::XMFLOAT4 &v,
                                       const DirectX::XMMATRIX &m)
{
    DirectX::XMFLOAT4 ret;

    ret.x = v.x * XMVectorGetX(m.r[0]) +
            v.y * XMVectorGetX(m.r[1]) + 
            v.z * XMVectorGetX(m.r[2]) + 
            v.w * XMVectorGetX(m.r[3]);

    ret.y = v.x * XMVectorGetY(m.r[0]) + 
            v.y * XMVectorGetY(m.r[1]) +
            v.z * XMVectorGetY(m.r[2]) + 
            v.w * XMVectorGetY(m.r[3]);

    ret.z = v.x * XMVectorGetZ(m.r[0]) + 
            v.y * XMVectorGetZ(m.r[1]) +
            v.z * XMVectorGetZ(m.r[2]) + 
            v.w * XMVectorGetZ(m.r[3]);

    ret.w = v.x * XMVectorGetW(m.r[0]) + 
            v.y * XMVectorGetW(m.r[1]) +
            v.z * XMVectorGetW(m.r[2]) +
            v.w * XMVectorGetW(m.r[3]);

    return ret;
}


float RadianAdd(float radian, float delta, float rangeMin, float rangMax)
{
    float ret;

    ret = radian + delta;

    float range = rangMax - rangeMin;

    if (delta > 0)
    {
        if (ret > rangMax)
        {
            ret -= range;
        }
    }
    else if (delta < 0)
    {
        if (ret < rangeMin)
        {
            ret += range;
        }
    }

    return ret;
}